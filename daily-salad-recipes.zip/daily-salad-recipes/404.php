<?php
/**
 * Daily Salad Recipes — 404 Not Found Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<section class="dsr-404">
		<div class="container">

			<div aria-hidden="true" class="dsr-404__number">404</div>

			<h1 class="dsr-404__title"><?php esc_html_e( 'Page Not Found', DSR_TEXT ); ?></h1>

			<p class="dsr-404__text">
				<?php esc_html_e( "Oops! This page seems to have gone missing. Let's get you back to some delicious salad recipes.", DSR_TEXT ); ?>
			</p>

			<div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;margin-bottom:var(--space-12);">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary">
					<?php esc_html_e( 'Back to Homepage', DSR_TEXT ); ?>
				</a>
				<a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="btn btn--secondary">
					<?php esc_html_e( 'Browse Recipes', DSR_TEXT ); ?>
				</a>
			</div>

			<!-- Search on 404 -->
			<div style="max-width:420px;margin:0 auto;">
				<p style="font-size:var(--fs-sm);color:var(--color-text-muted);margin-bottom:var(--space-4);">
					<?php esc_html_e( 'Or search for what you were looking for:', DSR_TEXT ); ?>
				</p>
				<?php get_search_form(); ?>
			</div>

		</div>
	</section>

</main>

<?php get_footer(); ?>

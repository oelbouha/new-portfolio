<?php
/**
 * Daily Salad Recipes — Product Archive Template
 *
 * Designed to look and feel EXACTLY like the category page (archive.php):
 * uses .dsr-archive-header, .dsr-filter-bar-wrap, .filter-btn,
 * and the standard site container grid layout.
 * URL: /products/
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<!-- Archive Header (Identical to Category Page Header) -->
	<header class="dsr-archive-header">
		<div class="container">
			<?php
			$intro_title = get_theme_mod( 'dsr_products_hero_title', esc_html__( 'Products', DSR_TEXT ) );
			$intro_sub   = get_theme_mod( 'dsr_products_hero_subtitle', esc_html__( 'Simple tools and guides to make meal planning, healthy cooking, and everyday eating easier.', DSR_TEXT ) );
			?>

			<h1 class="archive-header__title">
				<?php echo esc_html( $intro_title ); ?>
			</h1>

			<?php if ( $intro_sub ) : ?>
				<p class="archive-header__description"><?php echo esc_html( $intro_sub ); ?></p>
			<?php endif; ?>

			<p class="archive-header__count">
				<?php
				printf(
					/* translators: %d: product count */
					esc_html( _n( '%d Product', '%d Products', $wp_query->found_posts, DSR_TEXT ) ),
					absint( $wp_query->found_posts )
				);
				?>
			</p>
		</div>
	</header>

	<!-- Filter Bar (Identical to Category Page Filter Bar) -->
	<div class="dsr-filter-bar-wrap" style="background:var(--color-white);border-bottom:1px solid var(--color-border-light);">
		<div class="container">
			<div class="dsr-filter-bar" role="navigation" aria-label="<?php esc_attr_e( 'Filter products', DSR_TEXT ); ?>">
				<a href="<?php echo esc_url( get_post_type_archive_link( 'product' ) ); ?>" class="filter-btn <?php echo ! is_tax( 'product_category' ) ? 'is-active' : ''; ?>">
					<?php esc_html_e( 'All', DSR_TEXT ); ?>
				</a>
				<?php
				$product_cats = get_terms(
					array(
						'taxonomy'   => 'product_category',
						'hide_empty' => true,
					)
				);
				if ( ! empty( $product_cats ) && ! is_wp_error( $product_cats ) ) :
					$current_term_id = is_tax( 'product_category' ) ? get_queried_object_id() : 0;
					foreach ( $product_cats as $pcat ) :
						$is_active = ( $current_term_id === $pcat->term_id );
						?>
						<a
							href="<?php echo esc_url( get_term_link( $pcat ) ); ?>"
							class="filter-btn <?php echo $is_active ? 'is-active' : ''; ?>"
							<?php echo $is_active ? 'aria-current="page"' : ''; ?>
						>
							<?php echo esc_html( $pcat->name ); ?>
						</a>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<!-- Products Grid (Identical container & background to Category Page) -->
	<div style="padding:var(--space-16) 0;background:var(--color-bg);">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<div class="dsr-products-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/product/content', 'product' );
					endwhile;
					?>
				</div>

				<!-- Pagination -->
				<?php dsr_posts_pagination(); ?>

			<?php else : ?>

				<div class="dsr-products-empty">
					<h3><?php esc_html_e( 'No Products Found', DSR_TEXT ); ?></h3>
					<p><?php esc_html_e( 'We currently do not have any products available in this section. Please check back soon!', DSR_TEXT ); ?></p>
				</div>

			<?php endif; ?>

		</div>
	</div>

	<!-- Newsletter -->
	<?php get_template_part( 'template-parts/home/newsletter' ); ?>

</main>

<?php get_footer(); ?>

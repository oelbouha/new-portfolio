<?php
/**
 * Daily Salad Recipes — Archive Template (Category, Tag, Date, Author)
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<!-- Archive Header -->
	<header class="dsr-archive-header">
		<div class="container">

			<?php if ( is_category() ) : ?>

				<?php
				$cat_id    = get_queried_object_id();
				$thumb_id  = get_term_meta( $cat_id, 'thumbnail_id', true );
				if ( $thumb_id ) :
					?>
					<div class="archive-header__category-image">
						<?php echo wp_get_attachment_image( absint( $thumb_id ), 'dsr-category', false, array( 'alt' => esc_attr( single_cat_title( '', false ) ) ) ); ?>
					</div>
				<?php endif; ?>

				<h1 class="archive-header__title">
					<?php single_cat_title(); ?>
				</h1>

				<?php $cat_desc = category_description(); ?>
				<?php if ( $cat_desc ) : ?>
					<p class="archive-header__description"><?php echo wp_kses_post( $cat_desc ); ?></p>
				<?php endif; ?>

				<p class="archive-header__count">
					<?php
					printf(
						/* translators: %d: post count */
						esc_html( _n( '%d Recipe', '%d Recipes', $wp_query->found_posts, DSR_TEXT ) ),
						absint( $wp_query->found_posts )
					);
					?>
				</p>

			<?php elseif ( is_tag() ) : ?>

				<h1 class="archive-header__title">
					<?php
					printf(
						/* translators: %s: tag name */
						esc_html__( 'Tag: %s', DSR_TEXT ),
						'<span>' . single_tag_title( '', false ) . '</span>'
					);
					?>
				</h1>

			<?php elseif ( is_author() ) : ?>

				<h1 class="archive-header__title">
					<?php
					printf(
						/* translators: %s: author name */
						esc_html__( 'Recipes by %s', DSR_TEXT ),
						'<span>' . esc_html( get_the_author() ) . '</span>'
					);
					?>
				</h1>

			<?php elseif ( is_year() ) : ?>
				<h1 class="archive-header__title"><?php the_time( 'Y' ); ?></h1>

			<?php elseif ( is_month() ) : ?>
				<h1 class="archive-header__title"><?php the_time( 'F Y' ); ?></h1>

			<?php elseif ( is_day() ) : ?>
				<h1 class="archive-header__title"><?php the_time( get_option( 'date_format' ) ); ?></h1>

			<?php else : ?>
				<h1 class="archive-header__title"><?php esc_html_e( 'Recipes', DSR_TEXT ); ?></h1>
			<?php endif; ?>

		</div>
	</header>

	<!-- Filter Bar (categories list) -->
	<?php if ( is_category() || is_home() ) : ?>
		<div class="dsr-filter-bar-wrap" style="background:var(--color-white);border-bottom:1px solid var(--color-border-light);">
			<div class="container">
				<div class="dsr-filter-bar" role="navigation" aria-label="<?php esc_attr_e( 'Filter recipes', DSR_TEXT ); ?>">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="filter-btn <?php echo ! is_category() ? 'is-active' : ''; ?>">
						<?php esc_html_e( 'All', DSR_TEXT ); ?>
					</a>
					<?php
					$filter_cats = get_categories(
						array(
							'orderby'    => 'count',
							'order'      => 'DESC',
							'number'     => 10,
							'hide_empty' => true,
							'exclude'    => array( get_option( 'default_category' ) ),
						)
					);
					foreach ( $filter_cats as $fcat ) :
						$is_active = is_category( $fcat->term_id );
						?>
						<a
							href="<?php echo esc_url( get_category_link( $fcat->term_id ) ); ?>"
							class="filter-btn <?php echo $is_active ? 'is-active' : ''; ?>"
							<?php echo $is_active ? 'aria-current="page"' : ''; ?>
						>
							<?php echo esc_html( $fcat->name ); ?>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<!-- Recipe Grid -->
	<div style="padding:var(--space-16) 0;background:var(--color-bg);">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<div class="recipe-grid recipe-grid--4">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', 'recipe' );
					endwhile;
					?>
				</div>

				<!-- Pagination -->
				<?php dsr_posts_pagination(); ?>

			<?php else : ?>
				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
			<?php endif; ?>

		</div>
	</div>

</main>

<?php get_footer(); ?>

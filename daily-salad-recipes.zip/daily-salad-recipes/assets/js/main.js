/**
 * Daily Salad Recipes — Main JavaScript
 * Sticky header, mobile menu, search overlay, social share copy link.
 * Vanilla JS, no dependencies.
 */

(function () {
  'use strict';

  // =========================================================================
  // Utility: DOM ready
  // =========================================================================
  function ready(fn) {
    if (document.readyState !== 'loading') {
      fn();
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  // =========================================================================
  // Sticky header — shrinks on scroll
  // =========================================================================
  function initStickyHeader() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    let lastScroll = 0;
    const THRESHOLD = 50;

    function onScroll() {
      const scroll = window.scrollY;
      if (scroll > THRESHOLD) {
        header.classList.add('is-scrolled');
      } else {
        header.classList.remove('is-scrolled');
      }
      lastScroll = scroll;
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll(); // Run on load
  }

  // =========================================================================
  // Mobile menu
  // =========================================================================
  function initMobileMenu() {
    const toggle = document.querySelector('.mobile-menu-toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    const overlay = document.querySelector('.mobile-nav-overlay');
    const closeBtn = document.querySelector('.mobile-nav-close');

    if (!toggle || !mobileNav) return;

    function openMenu() {
      mobileNav.classList.add('is-open');
      if (overlay) overlay.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      toggle.setAttribute('aria-expanded', 'true');
      mobileNav.setAttribute('aria-hidden', 'false');
      // Focus first link
      const firstLink = mobileNav.querySelector('a');
      if (firstLink) firstLink.focus();
    }

    function closeMenu() {
      mobileNav.classList.remove('is-open');
      if (overlay) overlay.classList.remove('is-open');
      document.body.style.overflow = '';
      toggle.setAttribute('aria-expanded', 'false');
      mobileNav.setAttribute('aria-hidden', 'true');
      toggle.focus();
    }

    toggle.addEventListener('click', openMenu);
    if (closeBtn) closeBtn.addEventListener('click', closeMenu);
    if (overlay) overlay.addEventListener('click', closeMenu);

    // Mobile sub-menu toggles
    const parentItems = mobileNav.querySelectorAll('.menu-item-has-children > a');
    parentItems.forEach(function (link) {
      const toggleIcon = document.createElement('button');
      toggleIcon.className = 'mobile-submenu-toggle';
      toggleIcon.setAttribute('aria-label', 'Toggle sub-menu');
      toggleIcon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>';
      
      link.parentNode.insertBefore(toggleIcon, link.nextSibling);

      toggleIcon.addEventListener('click', function (e) {
        e.preventDefault();
        const parent = link.parentNode;
        parent.classList.toggle('is-expanded');
        toggleIcon.classList.toggle('is-active');
      });
    });

    // Close on Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileNav.classList.contains('is-open')) {
        closeMenu();
      }
    });
  }

  // =========================================================================
  // Search overlay
  // =========================================================================
  function initSearchOverlay() {
    const openBtns = document.querySelectorAll('.header-search-btn, .search-toggle-btn');
    const overlay = document.querySelector('.search-overlay');
    const closeBtn = document.querySelector('.search-overlay-close');
    const searchInput = overlay ? overlay.querySelector('input[type="search"]') : null;

    if (!overlay || openBtns.length === 0) return;

    function openSearch() {
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      if (searchInput) {
        setTimeout(function () { searchInput.focus(); }, 100);
      }
    }

    function closeSearch() {
      overlay.classList.remove('is-open');
      overlay.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }

    openBtns.forEach(function (btn) {
      btn.addEventListener('click', openSearch);
    });

    if (closeBtn) closeBtn.addEventListener('click', closeSearch);

    // Click backdrop
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeSearch();
    });

    // Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && overlay.classList.contains('is-open')) {
        closeSearch();
      }
    });
  }

  // =========================================================================
  // Copy link to clipboard
  // =========================================================================
  function initCopyLink() {
    document.addEventListener('click', function (e) {
      const btn = e.target.closest('.share-btn--copy');
      if (!btn) return;

      const url = btn.dataset.url || window.location.href;
      const label = btn.querySelector('.share-btn-label');
      const originalText = label ? label.textContent : '';
      const copiedText = (typeof DSR !== 'undefined' && DSR.i18n && DSR.i18n.copied)
        ? DSR.i18n.copied
        : 'Copied!';

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () {
          if (label) {
            label.textContent = copiedText;
            setTimeout(function () { label.textContent = originalText; }, 2000);
          }
        }).catch(function () {
          // Fallback
          fallbackCopy(url);
        });
      } else {
        fallbackCopy(url);
      }
    });

    function fallbackCopy(text) {
      const el = document.createElement('textarea');
      el.value = text;
      el.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
  }

  // =========================================================================
  // Lazy load images — IntersectionObserver polyfill-safe
  // =========================================================================
  function initLazyLoad() {
    if (!('IntersectionObserver' in window)) return;

    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    if (!lazyImages.length) return;

    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const img = entry.target;
          observer.unobserve(img);
        }
      });
    }, { rootMargin: '200px' });

    lazyImages.forEach(function (img) {
      observer.observe(img);
    });
  }

  // =========================================================================
  // Filter bar (category archive pages)
  // =========================================================================
  function initFilterBar() {
    const filterBtns = document.querySelectorAll('.filter-btn[data-filter]');
    if (!filterBtns.length) return;

    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        // Simple href-based filtering (SEO safe, no AJAX required).
        // If data-filter is a URL, navigate to it.
        const href = btn.getAttribute('href');
        if (href && href !== '#') {
          // Let the browser handle navigation naturally.
          return;
        }

        // Otherwise toggle active state (for JS-based filtering).
        filterBtns.forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
      });
    });
  }

  // =========================================================================
  // Newsletter widget area fallback — hide fallback if plugin widget present
  // =========================================================================
  function initNewsletter() {
    const widgetArea = document.querySelector('.newsletter-widget-area');
    const fallback = document.querySelector('.newsletter-fallback-form');

    if (!widgetArea || !fallback) return;

    // If the widget area has actual content (plugin form), hide fallback.
    const hasContent = widgetArea.children.length > 0 &&
      widgetArea.textContent.trim().length > 0;

    if (hasContent) {
      fallback.style.display = 'none';
    } else {
      // No plugin form — show fallback, hide widget area placeholder.
      widgetArea.style.display = 'none';
    }
  }

  // =========================================================================
  // Smooth anchor scrolling
  // =========================================================================
  function initSmoothScroll() {
    document.addEventListener('click', function (e) {
      const link = e.target.closest('a[href^="#"]');
      if (!link) return;

      const targetId = link.getAttribute('href').slice(1);
      if (!targetId) return;

      const target = document.getElementById(targetId);
      if (!target) return;

      e.preventDefault();

      const headerHeight = document.querySelector('.site-header')
        ? document.querySelector('.site-header').offsetHeight
        : 0;

      const targetTop = target.getBoundingClientRect().top + window.scrollY - headerHeight - 24;

      window.scrollTo({ top: targetTop, behavior: 'smooth' });
    });
  }

  // =========================================================================
  // Product Lightbox Modal (Click image to view full size)
  // =========================================================================
  function initLightboxModal() {
    const lightboxTriggers = document.querySelectorAll('[data-lightbox="product"], .dsr-product-image-lightbox');

    if (!lightboxTriggers.length) return;

    let modal = document.getElementById('dsr-lightbox-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'dsr-lightbox-modal';
      modal.className = 'dsr-lightbox-modal';
      modal.setAttribute('aria-hidden', 'true');
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-label', 'Image preview');
      modal.innerHTML = `
        <div class="dsr-lightbox-modal__backdrop"></div>
        <div class="dsr-lightbox-modal__container">
          <button type="button" class="dsr-lightbox-modal__close" aria-label="Close image preview">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
          <div class="dsr-lightbox-modal__content">
            <img class="dsr-lightbox-modal__img" src="" alt="" />
            <p class="dsr-lightbox-modal__caption"></p>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }

    const backdrop = modal.querySelector('.dsr-lightbox-modal__backdrop');
    const closeBtn = modal.querySelector('.dsr-lightbox-modal__close');
    const modalImg = modal.querySelector('.dsr-lightbox-modal__img');
    const modalCaption = modal.querySelector('.dsr-lightbox-modal__caption');

    function openLightbox(src, title) {
      modalImg.src = src;
      modalImg.alt = title || '';
      modalCaption.textContent = title || '';
      modal.classList.add('is-active');
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      closeBtn.focus();
    }

    function closeLightbox() {
      modal.classList.remove('is-active');
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }

    lightboxTriggers.forEach(function (trigger) {
      trigger.addEventListener('click', function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;

        e.preventDefault();
        const imgSrc = trigger.getAttribute('href') || (trigger.querySelector('img') ? trigger.querySelector('img').src : '');
        const imgTitle = trigger.getAttribute('data-title') || (trigger.querySelector('img') ? trigger.querySelector('img').alt : '');

        if (imgSrc) {
          openLightbox(imgSrc, imgTitle);
        }
      });
    });

    closeBtn.addEventListener('click', closeLightbox);
    backdrop.addEventListener('click', closeLightbox);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-active')) {
        closeLightbox();
      }
    });
  }

  // =========================================================================
  // Init all
  // =========================================================================
  ready(function () {
    initStickyHeader();
    initMobileMenu();
    initSearchOverlay();
    initCopyLink();
    initLazyLoad();
    initFilterBar();
    initNewsletter();
    initSmoothScroll();
    initLightboxModal();
  });

})();

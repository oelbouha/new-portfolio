/**
 * Daily Salad Recipes — Recipe Page JavaScript
 * Jump to recipe, print, reading progress.
 */

(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') {
      fn();
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  // =========================================================================
  // Jump to recipe button
  // =========================================================================
  function initJumpToRecipe() {
    const jumpBtns = document.querySelectorAll('.dsr-jump-to-recipe, .dr-jump-to-recipe, [data-jump-to-recipe]');
    if (!jumpBtns.length) return;

    jumpBtns.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        // Find the recipe card.
        const target = document.querySelector(
          '.dr-recipe-card-wrap, .wprm-recipe-container, .delicious-recipe-card, #recipe-card, .recipe-card-target'
        );
        if (!target) return;

        const headerHeight = document.querySelector('.site-header')
          ? document.querySelector('.site-header').offsetHeight
          : 0;
        const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 24;
        window.scrollTo({ top: top, behavior: 'smooth' });
      });
    });
  }

  // =========================================================================
  // Reading progress indicator
  // =========================================================================
  function initReadingProgress() {
    const bar = document.querySelector('.reading-progress-bar');
    if (!bar) return;

    function update() {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      const progress = total > 0 ? (window.scrollY / total) * 100 : 0;
      bar.style.width = Math.min(100, progress) + '%';
    }

    window.addEventListener('scroll', update, { passive: true });
  }

  // =========================================================================
  // Pinterest image hover — "Save" button on recipe images
  // =========================================================================
  function initPinterestSave() {
    const recipeImages = document.querySelectorAll(
      '.dsr-recipe-hero-image img, .dsr-post-hero-image img, .entry-content figure img'
    );

    recipeImages.forEach(function (img) {
      const wrap = img.closest('.dsr-recipe-hero-image, .dsr-post-hero-image, figure');
      if (!wrap) return;
      if (wrap.querySelector('.pinterest-save-btn')) return;

      const postUrl   = encodeURIComponent(window.location.href);
      const postTitle = encodeURIComponent(document.title);
      const imgSrc    = encodeURIComponent(img.src);
      const pinUrl    = 'https://pinterest.com/pin/create/button/?url=' + postUrl +
                        '&media=' + imgSrc + '&description=' + postTitle;

      const saveBtn = document.createElement('a');
      saveBtn.href = pinUrl;
      saveBtn.target = '_blank';
      saveBtn.rel = 'noopener noreferrer';
      saveBtn.className = 'pinterest-save-btn';
      saveBtn.setAttribute('aria-label', 'Save to Pinterest');
      saveBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/></svg> Save';

      wrap.style.position = 'relative';
      wrap.appendChild(saveBtn);
    });
  }

  // =========================================================================
  // Init
  // =========================================================================
  ready(function () {
    initJumpToRecipe();
    initReadingProgress();

    // Pinterest save — only if images are visible.
    if (document.querySelector('.dsr-recipe-hero-image, .dsr-post-hero-image')) {
      initPinterestSave();
    }
  });

})();

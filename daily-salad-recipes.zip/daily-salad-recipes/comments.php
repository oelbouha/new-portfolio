<?php
/**
 * Daily Salad Recipes — Comments Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$dsr_comment_count = get_comments_number();
			if ( '1' === $dsr_comment_count ) {
				printf(
					/* translators: 1: title. */
					esc_html__( 'One thought on &ldquo;%1$s&rdquo;', DSR_TEXT ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			} else {
				printf(
					/* translators: 1: comment count, 2: title. */
					esc_html( _nx( '%1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', $dsr_comment_count, 'comments title', DSR_TEXT ) ),
					number_format_i18n( $dsr_comment_count ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			}
			?>
		</h2>

		<?php the_comments_navigation(); ?>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 56,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation();

		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', DSR_TEXT ); ?></p>
		<?php endif; ?>

	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'        => esc_html__( 'Leave a Review or Comment', DSR_TEXT ),
			'title_reply_to'     => esc_html__( 'Leave a Reply to %s', DSR_TEXT ),
			'cancel_reply_link'  => esc_html__( 'Cancel Reply', DSR_TEXT ),
			'label_submit'       => esc_html__( 'Post Comment', DSR_TEXT ),
			'class_submit'       => 'btn btn-primary submit',
			'comment_field'      => '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Comment / Review', DSR_TEXT ) . ' <span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="5" required></textarea></p>',
		)
	);
	?>

</div>

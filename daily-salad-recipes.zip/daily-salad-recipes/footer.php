<?php
/**
 * Daily Salad Recipes — Footer Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$footer_desc = get_theme_mod( 'dsr_footer_description', esc_html__( 'Daily Salad Recipes: Easy & Healthy Salad Ideas. Fresh salad recipes for every day. Healthy, delicious, and simple to make.', DSR_TEXT ) );

// Social networks configuration.
$social_networks = array(
	'instagram' => array(
		'label' => esc_html__( 'Instagram', DSR_TEXT ),
		'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>',
	),
	'pinterest' => array(
		'label' => esc_html__( 'Pinterest', DSR_TEXT ),
		'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/></svg>',
	),
	'facebook'  => array(
		'label' => esc_html__( 'Facebook', DSR_TEXT ),
		'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
	),
	'youtube'   => array(
		'label' => esc_html__( 'YouTube', DSR_TEXT ),
		'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
	),
	'tiktok'    => array(
		'label' => esc_html__( 'TikTok', DSR_TEXT ),
		'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.17 8.17 0 004.78 1.52V6.75a4.85 4.85 0 01-1.01-.06z"/></svg>',
	),
);
?>

</div><!-- /#main-content -->

<footer class="site-footer" role="contentinfo" id="site-footer">

	<div class="footer-main">
		<div class="container">
			<div class="footer-grid">

				<!-- Brand Column -->
				<div class="footer-brand">
					<div class="footer-logo">
						<?php dsr_logo(); ?>
					</div>
					<?php if ( $footer_desc ) : ?>
						<p class="footer-description"><?php echo esc_html( $footer_desc ); ?></p>
					<?php endif; ?>

					<!-- Social Icons -->
					<div class="footer-social" aria-label="<?php esc_attr_e( 'Social Media Links', DSR_TEXT ); ?>">
						<?php
						foreach ( $social_networks as $key => $data ) {
							$url = get_theme_mod( 'dsr_social_' . $key, '#' );
							if ( empty( $url ) ) {
								$url = '#';
							}
							printf(
								'<a href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s">%3$s</a>',
								esc_url( $url ),
								esc_attr( $data['label'] ),
								$data['icon']
							);
						}
						?>
					</div>
				</div>

				<!-- Navigation Column -->
				<div class="footer-nav-column">
					<h4><?php esc_html_e( 'Explore', DSR_TEXT ); ?></h4>
					<?php if ( has_nav_menu( 'footer' ) ) : ?>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'footer',
								'container'      => false,
								'fallback_cb'    => false,
								'depth'          => 1,
							)
						);
						?>
					<?php else : ?>
						<ul>
							<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', DSR_TEXT ); ?></a></li>
							<li><a href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'Recipes', DSR_TEXT ); ?></a></li>
							<li><a href="<?php echo esc_url( home_url( '/recipe-categories/' ) ); ?>"><?php esc_html_e( 'Categories', DSR_TEXT ); ?></a></li>
							<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About', DSR_TEXT ); ?></a></li>
							<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', DSR_TEXT ); ?></a></li>
						</ul>
					<?php endif; ?>
				</div>

				<!-- Legal Column -->
				<div class="footer-nav-column">
					<h4><?php esc_html_e( 'Legal', DSR_TEXT ); ?></h4>
					<?php if ( has_nav_menu( 'legal' ) ) : ?>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'legal',
								'container'      => false,
								'fallback_cb'    => false,
								'depth'          => 1,
							)
						);
						?>
					<?php else : ?>
						<ul>
							<li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php esc_html_e( 'Privacy Policy', DSR_TEXT ); ?></a></li>
							<li><a href="<?php echo esc_url( home_url( '/terms-of-use/' ) ); ?>"><?php esc_html_e( 'Terms of Use', DSR_TEXT ); ?></a></li>
						</ul>
					<?php endif; ?>
				</div>

			</div>
		</div>
	</div>

	<!-- Footer Bottom -->
	<div class="footer-bottom">
		<div class="container">
			<div class="footer-bottom-inner">
				<p class="footer-copyright">
					<?php
					printf(
						/* translators: 1: Copyright symbol, 2: year, 3: site name */
						esc_html__( '%1$s %2$s %3$s. All rights reserved.', DSR_TEXT ),
						'&copy;',
						esc_html( gmdate( 'Y' ) ),
						esc_html( get_bloginfo( 'name' ) )
					);
					?>
				</p>

				<?php if ( has_nav_menu( 'legal' ) ) : ?>
					<nav class="footer-legal-nav" aria-label="<?php esc_attr_e( 'Legal Navigation', DSR_TEXT ); ?>">
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'legal',
								'container'      => false,
								'fallback_cb'    => false,
								'depth'          => 1,
							)
						);
						?>
					</nav>
				<?php else : ?>
					<nav class="footer-legal-nav" aria-label="<?php esc_attr_e( 'Legal Navigation', DSR_TEXT ); ?>">
						<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php esc_html_e( 'Privacy', DSR_TEXT ); ?></a>
						<a href="<?php echo esc_url( home_url( '/terms-of-use/' ) ); ?>"><?php esc_html_e( 'Terms', DSR_TEXT ); ?></a>
					</nav>
				<?php endif; ?>

			</div>
		</div>
	</div>

</footer>

<?php wp_footer(); ?>
</body>
</html>

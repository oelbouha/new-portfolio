<?php
/**
 * Daily Salad Recipes — Front Page (Homepage)
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<!-- 1. Hero -->
	<?php get_template_part( 'template-parts/home/hero' ); ?>

	<!-- 2. Featured Categories -->
	<?php get_template_part( 'template-parts/home/featured-categories' ); ?>

	<!-- 3. Popular Recipes Grid -->
	<?php get_template_part( 'template-parts/home/featured-recipes' ); ?>

	<!-- 4. About Strip -->
	<?php get_template_part( 'template-parts/home/about-strip' ); ?>

	<!-- 5. Latest Recipes -->
	<?php get_template_part( 'template-parts/home/latest-recipes' ); ?>

	<!-- 6. Category Showcase Section 1 -->
	<?php get_template_part( 'template-parts/home/category-showcase', null, array( 'showcase_num' => 1 ) ); ?>

	<!-- 7. Category Showcase Section 2 -->
	<?php get_template_part( 'template-parts/home/category-showcase', null, array( 'showcase_num' => 2 ) ); ?>

	<!-- 8. Newsletter -->
	<?php get_template_part( 'template-parts/home/newsletter' ); ?>

</main>

<?php get_footer(); ?>

<?php
/**
 * Daily Salad Recipes — Theme Functions
 *
 * @package DailySaladRecipes
 * @version 1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --------------------------------------------------------------------------
// Constants
// --------------------------------------------------------------------------
define( 'DSR_VERSION',   '1.5.0' );
define( 'DSR_DIR',       get_template_directory() );
define( 'DSR_URI',       get_template_directory_uri() );
define( 'DSR_TEXT',      'daily-salad-recipes' );

// --------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------
$dsr_includes = array(
	'/inc/setup.php',
	'/inc/enqueue.php',
	'/inc/widgets.php',
	'/inc/customizer.php',
	'/inc/template-functions.php',
	'/inc/compatibility.php',
	'/inc/products.php',
);

foreach ( $dsr_includes as $file ) {
	$filepath = DSR_DIR . $file;
	if ( file_exists( $filepath ) ) {
		require_once $filepath;
	}
}

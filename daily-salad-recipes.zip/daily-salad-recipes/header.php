<?php
/**
 * Daily Salad Recipes — Header Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link" href="#main-content"><?php esc_html_e( 'Skip to content', DSR_TEXT ); ?></a>

<!-- Search Overlay -->
<div
	class="search-overlay"
	role="dialog"
	aria-modal="true"
	aria-label="<?php esc_attr_e( 'Search recipes', DSR_TEXT ); ?>"
	aria-hidden="true"
	id="search-overlay"
>
	<div class="search-overlay-inner">
		<span class="search-overlay-label"><?php esc_html_e( 'What are you craving?', DSR_TEXT ); ?></span>
		<?php get_search_form(); ?>
	</div>
	<button
		type="button"
		class="search-overlay-close"
		aria-label="<?php esc_attr_e( 'Close search', DSR_TEXT ); ?>"
	>&times;</button>
</div>

<!-- Mobile Nav Overlay -->
<div class="mobile-nav-overlay" aria-hidden="true"></div>

<!-- Mobile Nav -->
<nav
	class="mobile-nav"
	id="mobile-nav"
	aria-label="<?php esc_attr_e( 'Mobile Navigation', DSR_TEXT ); ?>"
	aria-hidden="true"
>
	<div class="mobile-nav-header">
		<?php dsr_logo(); ?>
		<button
			type="button"
			class="mobile-nav-close"
			aria-label="<?php esc_attr_e( 'Close menu', DSR_TEXT ); ?>"
		>
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
		</button>
	</div>

	<?php if ( has_nav_menu( 'primary' ) ) : ?>
		<div class="mobile-menu">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_class'     => 'menu',
					'container'      => false,
					'depth'          => 2,
					'fallback_cb'    => false,
				)
			);
			?>
		</div>
	<?php endif; ?>

	<!-- Social links in mobile nav -->
	<div class="mobile-nav-social">
		<?php
		$social_networks = array(
			'instagram' => array(
				'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>',
				'label' => esc_html__( 'Instagram', DSR_TEXT ),
			),
			'pinterest' => array(
				'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/></svg>',
				'label' => esc_html__( 'Pinterest', DSR_TEXT ),
			),
			'facebook'  => array(
				'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
				'label' => esc_html__( 'Facebook', DSR_TEXT ),
			),
		);

		foreach ( $social_networks as $key => $data ) {
			$url = get_theme_mod( 'dsr_social_' . $key, '' );
			if ( $url ) {
				printf(
					'<a href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s">%3$s</a>',
					esc_url( $url ),
					esc_attr( $data['label'] ),
					wp_kses_post( $data['icon'] )
				);
			}
		}
		?>
	</div>
</nav>

<!-- Site Header -->
<header class="site-header" role="banner" id="site-header">
	<div class="container">

		<!-- Logo -->
		<div class="site-logo" id="site-logo">
			<?php dsr_logo(); ?>
		</div>

		<!-- Primary Navigation -->
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<nav class="primary-nav" aria-label="<?php esc_attr_e( 'Primary Navigation', DSR_TEXT ); ?>" id="primary-navigation">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_class'     => 'menu',
						'container'      => false,
						'depth'          => 2,
						'fallback_cb'    => false,
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<!-- Header Actions -->
		<div class="header-actions">
			<!-- Search button -->
			<button
				type="button"
				class="header-search-btn"
				aria-label="<?php esc_attr_e( 'Open search', DSR_TEXT ); ?>"
				aria-controls="search-overlay"
				aria-expanded="false"
				id="header-search-btn"
			>
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
			</button>

			<!-- Newsletter CTA -->
			<a
				href="#newsletter"
				class="btn btn--primary btn--sm header-newsletter-btn"
				id="header-newsletter-cta"
			>
				<?php esc_html_e( 'Get Recipes', DSR_TEXT ); ?>
			</a>

			<!-- Mobile menu toggle -->
			<button
				type="button"
				class="mobile-menu-toggle"
				aria-label="<?php esc_attr_e( 'Open navigation menu', DSR_TEXT ); ?>"
				aria-controls="mobile-nav"
				aria-expanded="false"
				id="mobile-menu-toggle"
			>
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
			</button>
		</div>

	</div>
</header>

<?php
// Header ad slot.
if ( is_active_sidebar( 'ad-header' ) ) :
	?>
	<div class="header-ad-slot" aria-label="<?php esc_attr_e( 'Advertisement', DSR_TEXT ); ?>">
		<div class="container">
			<?php dynamic_sidebar( 'ad-header' ); ?>
		</div>
	</div>
	<?php
endif;
?>

<div id="main-content" tabindex="-1">

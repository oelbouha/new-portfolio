<?php
/**
 * Daily Salad Recipes — Home Template (blog index when front page is static)
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<div class="dsr-archive-header">
		<div class="container">
			<h1 class="archive-header__title"><?php esc_html_e( 'All Recipes', DSR_TEXT ); ?></h1>
			<p class="archive-header__description"><?php esc_html_e( 'Browse all our fresh salad recipes.', DSR_TEXT ); ?></p>
		</div>
	</div>

	<div style="padding:var(--space-16) 0;background:var(--color-bg);">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<div class="recipe-grid recipe-grid--4">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', 'recipe' );
					endwhile;
					?>
				</div>

				<?php dsr_posts_pagination(); ?>

			<?php else : ?>
				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
			<?php endif; ?>

		</div>
	</div>

</main>

<?php get_footer(); ?>

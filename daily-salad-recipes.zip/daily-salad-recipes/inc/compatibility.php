<?php
/**
 * Daily Salad Recipes — Plugin Compatibility
 *
 * Hooks and filters for WP Delicious, Yoast SEO, Rank Math,
 * Contact Form 7, and Gutenberg.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// =========================================================================
// WP DELICIOUS / DELICIOUS RECIPES
// =========================================================================

/**
 * Add body class when WP Delicious is active.
 */
function dsr_wpdelicious_body_class( $classes ) {
	if ( class_exists( 'Delicious_Recipes' ) || defined( 'DR_PLUGIN_FILE' ) ) {
		$classes[] = 'dsr-wpdelicious-active';
	}
	return $classes;
}
add_filter( 'body_class', 'dsr_wpdelicious_body_class' );

/**
 * Ensure WP Delicious recipe post type is included in theme queries.
 */
function dsr_include_recipe_post_type( $query ) {
	if ( ! is_admin() && $query->is_main_query() ) {
		// On the blog index, include recipes.
		if ( $query->is_home() ) {
			$post_types   = $query->get( 'post_type' );
			$post_types   = empty( $post_types ) ? array( 'post' ) : (array) $post_types;
			if ( ! in_array( 'recipe', $post_types, true ) ) {
				$post_types[] = 'recipe';
				// Uncomment to include recipes in the blog loop:
				// $query->set( 'post_type', $post_types );
			}
		}
	}
}
add_action( 'pre_get_posts', 'dsr_include_recipe_post_type' );

/**
 * Register WP Delicious recipe post type as supported by theme.
 * (The plugin registers the post type itself; we just declare support.)
 */
function dsr_wpdelicious_theme_support() {
	if ( class_exists( 'Delicious_Recipes' ) || defined( 'DR_PLUGIN_FILE' ) ) {
		add_theme_support( 'delicious-recipes' );
	}
}
add_action( 'after_setup_theme', 'dsr_wpdelicious_theme_support' );

/**
 * Enqueue recipe-specific CSS on WP Delicious recipe single pages.
 */
function dsr_wpdelicious_recipe_styles() {
	if ( is_singular( 'recipe' ) ) {
		wp_enqueue_style( 'dsr-recipe' );
	}
}
add_action( 'wp_enqueue_scripts', 'dsr_wpdelicious_recipe_styles' );

// =========================================================================
// YOAST SEO
// =========================================================================

/**
 * Let Yoast SEO handle breadcrumbs (declared in template-functions.php).
 * Disable theme's own schema if Yoast is outputting it.
 */
function dsr_yoast_breadcrumb_enabled( $enabled ) {
	return true; // Always enable Yoast breadcrumbs.
}
add_filter( 'wpseo_breadcrumb_enabled', 'dsr_yoast_breadcrumb_enabled' );

// =========================================================================
// RANK MATH
// =========================================================================
// Rank Math breadcrumbs are supported via dsr_breadcrumbs() in template-functions.php.
// No additional hooks needed.

// =========================================================================
// CONTACT FORM 7
// =========================================================================

/**
 * Wrap Contact Form 7 forms in a styled div.
 */
function dsr_cf7_form_wrapper( $content ) {
	if ( function_exists( 'wpcf7_enqueue_scripts' ) ) {
		return '<div class="dsr-cf7-wrapper">' . $content . '</div>';
	}
	return $content;
}
// Hook only if CF7 is active — checked lazily in the filter.

// =========================================================================
// GUTENBERG / BLOCK EDITOR
// =========================================================================

/**
 * Add theme color palette to the block editor.
 */
function dsr_block_editor_settings() {
	add_theme_support(
		'editor-color-palette',
		array(
			array(
				'name'  => esc_html__( 'Primary Green', DSR_TEXT ),
				'slug'  => 'primary',
				'color' => '#173F35',
			),
			array(
				'name'  => esc_html__( 'Secondary Olive', DSR_TEXT ),
				'slug'  => 'secondary',
				'color' => '#71845B',
			),
			array(
				'name'  => esc_html__( 'Accent Terracotta', DSR_TEXT ),
				'slug'  => 'accent',
				'color' => '#C96F4A',
			),
			array(
				'name'  => esc_html__( 'Background Ivory', DSR_TEXT ),
				'slug'  => 'background',
				'color' => '#FAF8F3',
			),
			array(
				'name'  => esc_html__( 'Text Charcoal', DSR_TEXT ),
				'slug'  => 'text',
				'color' => '#202522',
			),
			array(
				'name'  => esc_html__( 'White', DSR_TEXT ),
				'slug'  => 'white',
				'color' => '#FFFFFF',
			),
		)
	);

	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'Small', DSR_TEXT ),
				'slug' => 'small',
				'size' => 14,
			),
			array(
				'name' => esc_html__( 'Normal', DSR_TEXT ),
				'slug' => 'normal',
				'size' => 16,
			),
			array(
				'name' => esc_html__( 'Medium', DSR_TEXT ),
				'slug' => 'medium',
				'size' => 18,
			),
			array(
				'name' => esc_html__( 'Large', DSR_TEXT ),
				'slug' => 'large',
				'size' => 24,
			),
		)
	);
}
add_action( 'after_setup_theme', 'dsr_block_editor_settings' );

// =========================================================================
// SECURITY: Prevent direct access to PHP files
// =========================================================================
// Already handled by the ABSPATH check at the top of every file.

// =========================================================================
// COMPATIBILITY: Remove emoji scripts (performance)
// =========================================================================
function dsr_disable_emoji() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'dsr_disable_emoji' );

// =========================================================================
// PERFORMANCE: Remove unnecessary head tags
// =========================================================================
function dsr_clean_head() {
	remove_action( 'wp_head', 'wp_generator' );            // WP version.
	remove_action( 'wp_head', 'wlwmanifest_link' );        // Windows Live Writer.
	remove_action( 'wp_head', 'rsd_link' );                // RSD link.
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );    // Shortlink.
}
add_action( 'init', 'dsr_clean_head' );

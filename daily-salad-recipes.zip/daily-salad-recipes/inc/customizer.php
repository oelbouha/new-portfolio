<?php
/**
 * Daily Salad Recipes — Customizer Settings
 *
 * All theme options configurable from Appearance → Customize.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function dsr_customizer( $wp_customize ) {

	// =========================================================================
	// PANEL: Theme Options
	// =========================================================================
	$wp_customize->add_panel(
		'dsr_theme_options',
		array(
			'title'       => esc_html__( 'Daily Salad Recipes Options', DSR_TEXT ),
			'description' => esc_html__( 'Customize your Daily Salad Recipes theme.', DSR_TEXT ),
			'priority'    => 130,
		)
	);

	// =========================================================================
	// SECTION: Hero
	// =========================================================================
	$wp_customize->add_section(
		'dsr_hero',
		array(
			'title'    => esc_html__( 'Homepage Hero', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 10,
		)
	);

	// Hero Image.
	$wp_customize->add_setting(
		'dsr_hero_image',
		array(
			'default'           => '',
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'dsr_hero_image',
			array(
				'label'     => esc_html__( 'Hero Background Image', DSR_TEXT ),
				'section'   => 'dsr_hero',
				'mime_type' => 'image',
			)
		)
	);

	// Hero Eyebrow.
	$wp_customize->add_setting(
		'dsr_hero_eyebrow',
		array(
			'default'           => esc_html__( 'FRESH • SIMPLE • EVERYDAY', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_eyebrow',
		array(
			'label'   => esc_html__( 'Hero Eyebrow Text', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'text',
		)
	);

	// Hero Heading.
	$wp_customize->add_setting(
		'dsr_hero_heading',
		array(
			'default'           => esc_html__( 'Daily Salad Recipes for Every Day', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_heading',
		array(
			'label'   => esc_html__( 'Hero Heading', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'text',
		)
	);

	// Hero Description.
	$wp_customize->add_setting(
		'dsr_hero_description',
		array(
			'default'           => esc_html__( 'Fresh, easy, and delicious salad recipes for everyday meals. Discover simple salads made with fresh ingredients.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_description',
		array(
			'label'   => esc_html__( 'Hero Description', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'textarea',
		)
	);

	// Hero Primary Button Text.
	$wp_customize->add_setting(
		'dsr_hero_btn_primary_text',
		array(
			'default'           => esc_html__( 'EXPLORE SALAD RECIPES', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_btn_primary_text',
		array(
			'label'   => esc_html__( 'Primary Button Text', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'text',
		)
	);

	// Hero Primary Button URL.
	$wp_customize->add_setting(
		'dsr_hero_btn_primary_url',
		array(
			'default'           => '/recipes/',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_btn_primary_url',
		array(
			'label'   => esc_html__( 'Primary Button URL', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'url',
		)
	);

	// Hero Secondary Button Text.
	$wp_customize->add_setting(
		'dsr_hero_btn_secondary_text',
		array(
			'default'           => esc_html__( 'VIEW LATEST RECIPES', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_btn_secondary_text',
		array(
			'label'   => esc_html__( 'Secondary Button Text', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'text',
		)
	);

	// Hero Secondary Button URL.
	$wp_customize->add_setting(
		'dsr_hero_btn_secondary_url',
		array(
			'default'           => '#latest-recipes',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_hero_btn_secondary_url',
		array(
			'label'   => esc_html__( 'Secondary Button URL', DSR_TEXT ),
			'section' => 'dsr_hero',
			'type'    => 'text',
		)
	);

	// =========================================================================
	// SECTION: Homepage Section Headings & Links
	// =========================================================================
	$wp_customize->add_section(
		'dsr_homepage_titles',
		array(
			'title'    => esc_html__( 'Homepage Section Titles & Links', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 15,
		)
	);

	// Categories Section
	$wp_customize->add_setting( 'dsr_cat_eyebrow', array( 'default' => esc_html__( 'EXPLORE', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_eyebrow', array( 'label' => esc_html__( 'Categories Eyebrow', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_heading', array( 'default' => esc_html__( 'Browse Salad Recipes by Category', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_heading', array( 'label' => esc_html__( 'Categories Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_subtitle', array( 'default' => esc_html__( 'Find the right salad for any meal, from fresh vegetables and green salads to hearty chicken, potato, and healthy salad recipes.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_cat_subtitle', array( 'label' => esc_html__( 'Categories Subtitle', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'textarea' ) );

	// Category Selection Mode
	$wp_customize->add_setting( 'dsr_cat_mode', array( 'default' => 'auto', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_mode', array(
		'label'   => esc_html__( 'Category Display Mode', DSR_TEXT ),
		'section' => 'dsr_homepage_titles',
		'type'    => 'select',
		'choices' => array(
			'auto'   => esc_html__( 'Automatic (Show all active WordPress categories)', DSR_TEXT ),
			'manual' => esc_html__( 'Manual Selection (Choose specific categories below)', DSR_TEXT ),
			'custom' => esc_html__( 'Custom Built-in Cards (Custom titles & links below)', DSR_TEXT ),
		),
	) );

	// Exclude categories list
	$wp_customize->add_setting( 'dsr_cat_exclude_list', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_exclude_list', array(
		'label'       => esc_html__( 'Exclude Categories (Comma-separated IDs or Slugs)', DSR_TEXT ),
		'description' => esc_html__( 'Enter category IDs or slugs to remove/exclude (e.g. 5, 12, uncategorized)', DSR_TEXT ),
		'section'     => 'dsr_homepage_titles',
		'type'        => 'text',
	) );

	// 8 Category Slots for Manual/Custom Pickers with Enable Checkbox
	for ( $i = 1; $i <= 8; $i++ ) {
		$wp_customize->add_setting( "dsr_cat_enable_{$i}", array( 'default' => true, 'sanitize_callback' => 'rest_sanitize_boolean' ) );
		$wp_customize->add_control( "dsr_cat_enable_{$i}", array(
			/* translators: %d: slot index */
			'label'   => sprintf( esc_html__( 'Show Category Item %d', DSR_TEXT ), $i ),
			'section' => 'dsr_homepage_titles',
			'type'    => 'checkbox',
		) );

		$wp_customize->add_setting( "dsr_cat_select_{$i}", array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( "dsr_cat_select_{$i}", array(
			/* translators: %d: slot index */
			'label'   => sprintf( esc_html__( 'Category Slot %d WP Category', DSR_TEXT ), $i ),
			'section' => 'dsr_homepage_titles',
			'type'    => 'select',
			'choices' => $cat_choices,
		) );

		$wp_customize->add_setting( "dsr_cat_image_{$i}", array( 'default' => '', 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, "dsr_cat_image_{$i}", array(
			/* translators: %d: slot index */
			'label'     => sprintf( esc_html__( 'Category Slot %d Custom Image', DSR_TEXT ), $i ),
			'section'   => 'dsr_homepage_titles',
			'mime_type' => 'image',
		) ) );
	}

	// Category Item 1 Custom Fallback Settings
	$wp_customize->add_setting( 'dsr_cat_name_1', array( 'default' => esc_html__( 'Chicken Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_name_1', array( 'label' => esc_html__( 'Fallback Category 1 Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_count_1', array( 'default' => esc_html__( '1 Recipe', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_count_1', array( 'label' => esc_html__( 'Fallback Category 1 Count/Subtext', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_url_1', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'dsr_cat_url_1', array( 'label' => esc_html__( 'Fallback Category 1 Link URL', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'url' ) );

	// Category Item 2 Custom Fallback Settings
	$wp_customize->add_setting( 'dsr_cat_name_2', array( 'default' => esc_html__( 'Potato Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_name_2', array( 'label' => esc_html__( 'Fallback Category 2 Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_count_2', array( 'default' => esc_html__( '1 Recipe', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_count_2', array( 'label' => esc_html__( 'Fallback Category 2 Count/Subtext', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_url_2', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'dsr_cat_url_2', array( 'label' => esc_html__( 'Fallback Category 2 Link URL', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'url' ) );

	// Category Item 3 Custom Fallback Settings
	$wp_customize->add_setting( 'dsr_cat_name_3', array( 'default' => esc_html__( 'International Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_name_3', array( 'label' => esc_html__( 'Fallback Category 3 Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_count_3', array( 'default' => esc_html__( '1 Recipe', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_cat_count_3', array( 'label' => esc_html__( 'Fallback Category 3 Count/Subtext', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_cat_url_3', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'dsr_cat_url_3', array( 'label' => esc_html__( 'Fallback Category 3 Link URL', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'url' ) );

	// Featured Section
	$wp_customize->add_setting( 'dsr_featured_eyebrow', array( 'default' => esc_html__( 'TRY THESE', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_featured_eyebrow', array( 'label' => esc_html__( 'Featured Recipes Eyebrow', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_featured_heading', array( 'default' => esc_html__( 'Popular Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_featured_heading', array( 'label' => esc_html__( 'Featured Recipes Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_featured_subtitle', array( 'default' => esc_html__( 'Simple and delicious salad recipes worth trying.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_featured_subtitle', array( 'label' => esc_html__( 'Featured Recipes Subtitle', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_featured_link_text', array( 'default' => esc_html__( 'All Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_featured_link_text', array( 'label' => esc_html__( 'Featured Section Link Text', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_featured_link_url', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'dsr_featured_link_url', array( 'label' => esc_html__( 'Featured Section Link URL', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'url' ) );

	// Latest Section
	$wp_customize->add_setting( 'dsr_latest_eyebrow', array( 'default' => esc_html__( 'NEW RECIPES', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_latest_eyebrow', array( 'label' => esc_html__( 'Latest Recipes Eyebrow', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_latest_heading', array( 'default' => esc_html__( 'Latest Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_latest_heading', array( 'label' => esc_html__( 'Latest Recipes Title', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_latest_link_text', array( 'default' => esc_html__( 'View All', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_latest_link_text', array( 'label' => esc_html__( 'Latest Section Link Text', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'text' ) );

	$wp_customize->add_setting( 'dsr_latest_link_url', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'dsr_latest_link_url', array( 'label' => esc_html__( 'Latest Section Link URL', DSR_TEXT ), 'section' => 'dsr_homepage_titles', 'type' => 'url' ) );

	// =========================================================================
	// SECTION: Recipe Cards Design & Styling
	// =========================================================================
	$wp_customize->add_section(
		'dsr_recipe_cards_style',
		array(
			'title'    => esc_html__( 'Recipe Cards Design', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 18,
		)
	);

	// Card Padding
	$wp_customize->add_setting( 'dsr_card_padding', array( 'default' => 'standard', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_card_padding', array(
		'label'   => esc_html__( 'Card Padding', DSR_TEXT ),
		'section' => 'dsr_recipe_cards_style',
		'type'    => 'select',
		'choices' => array(
			'compact'  => esc_html__( 'Compact (Tight spacing)', DSR_TEXT ),
			'standard' => esc_html__( 'Standard (Recommended)', DSR_TEXT ),
			'spacious' => esc_html__( 'Spacious (Generous padding)', DSR_TEXT ),
		),
	) );

	// Card Aspect Ratio
	$wp_customize->add_setting( 'dsr_card_aspect_ratio', array( 'default' => '4/5', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_card_aspect_ratio', array(
		'label'   => esc_html__( 'Card Image Aspect Ratio', DSR_TEXT ),
		'section' => 'dsr_recipe_cards_style',
		'type'    => 'select',
		'choices' => array(
			'4/5' => esc_html__( '4:5 Portrait (Recommended)', DSR_TEXT ),
			'1/1' => esc_html__( '1:1 Square', DSR_TEXT ),
			'3/4' => esc_html__( '3:4 Tall Portrait', DSR_TEXT ),
		),
	) );

	// Card Background Color
	$wp_customize->add_setting( 'dsr_card_bg_color', array( 'default' => '#ffffff', 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'dsr_card_bg_color', array(
		'label'   => esc_html__( 'Card Background Color', DSR_TEXT ),
		'section' => 'dsr_recipe_cards_style',
	) ) );

	// Card Box Shadow
	$wp_customize->add_setting( 'dsr_card_shadow', array( 'default' => 'soft', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_card_shadow', array(
		'label'   => esc_html__( 'Card Box Shadow', DSR_TEXT ),
		'section' => 'dsr_recipe_cards_style',
		'type'    => 'select',
		'choices' => array(
			'flat'     => esc_html__( 'Flat (Border only)', DSR_TEXT ),
			'soft'     => esc_html__( 'Soft Shadow (Subtle lift)', DSR_TEXT ),
			'elevated' => esc_html__( 'Elevated Shadow (Deep float)', DSR_TEXT ),
		),
	) );

	// =========================================================================
	// SECTION: About Page Options
	// =========================================================================
	$wp_customize->add_section(
		'dsr_about_page_opts',
		array(
			'title'    => esc_html__( 'About Page Settings', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 25,
		)
	);

	// Hero Eyebrow
	$wp_customize->add_setting( 'dsr_about_hero_eyebrow', array( 'default' => esc_html__( 'Our Mission & Story', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_hero_eyebrow', array( 'label' => esc_html__( 'Hero Eyebrow Text', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );

	// Hero Title
	$wp_customize->add_setting( 'dsr_about_hero_title', array( 'default' => esc_html__( 'Vibrant, Delicious & Wholesome Salads Every Single Day', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_hero_title', array( 'label' => esc_html__( 'Hero Title', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );

	// Hero Subtitle
	$wp_customize->add_setting( 'dsr_about_hero_subtitle', array( 'default' => esc_html__( 'We are dedicated to proving that healthy eating should never be boring, repetitive, or complicated.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_hero_subtitle', array( 'label' => esc_html__( 'Hero Subtitle', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Story Image
	$wp_customize->add_setting( 'dsr_about_story_image', array( 'default' => 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1000&q=80', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'dsr_about_story_image', array( 'label' => esc_html__( 'Story Main Image', DSR_TEXT ), 'section' => 'dsr_about_page_opts' ) ) );

	// Story Heading
	$wp_customize->add_setting( 'dsr_about_story_heading', array( 'default' => esc_html__( 'Welcome to Daily Salad Recipes', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_story_heading', array( 'label' => esc_html__( 'Story Heading', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );

	// Story Lead Text
	$wp_customize->add_setting( 'dsr_about_story_lead', array( 'default' => esc_html__( 'What started as a small personal obsession with fresh produce has grown into a vibrant publication dedicated to salad lovers worldwide.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_story_lead', array( 'label' => esc_html__( 'Story Lead Paragraph', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Story Paragraph 1
	$wp_customize->add_setting( 'dsr_about_story_p1', array( 'default' => esc_html__( 'At Daily Salad Recipes, we believe a great salad is an art form — combining textures, colors, homemade dressings, and nutritionally dense ingredients to create meals you genuinely crave.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_story_p1', array( 'label' => esc_html__( 'Story Paragraph 1', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Story Paragraph 2
	$wp_customize->add_setting( 'dsr_about_story_p2', array( 'default' => esc_html__( 'Whether you are looking for quick 15-minute weekday lunch bowls, high-protein post-workout options, crunchy Mediterranean dishes, or decadent dinner salads for entertaining guests, we have got you covered.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_story_p2', array( 'label' => esc_html__( 'Story Paragraph 2', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Pillars Eyebrow
	$wp_customize->add_setting( 'dsr_about_values_eyebrow', array( 'default' => esc_html__( 'What Drives Us', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_values_eyebrow', array( 'label' => esc_html__( 'Pillars Eyebrow', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );

	// Pillars Title
	$wp_customize->add_setting( 'dsr_about_values_title', array( 'default' => esc_html__( 'Our Culinary Promises', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_values_title', array( 'label' => esc_html__( 'Pillars Title', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );

	// Value 1
	$wp_customize->add_setting( 'dsr_about_val1_icon', array( 'default' => '🥗', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val1_icon', array( 'label' => esc_html__( 'Pillar 1 Icon Emoji', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val1_title', array( 'default' => esc_html__( 'Flavor First', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val1_title', array( 'label' => esc_html__( 'Pillar 1 Title', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val1_desc', array( 'default' => esc_html__( 'No bland greens here. Every recipe balances crunch, zesty dressings, quality proteins, and bold seasonings.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_val1_desc', array( 'label' => esc_html__( 'Pillar 1 Description', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Value 2
	$wp_customize->add_setting( 'dsr_about_val2_icon', array( 'default' => '🥑', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val2_icon', array( 'label' => esc_html__( 'Pillar 2 Icon Emoji', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val2_title', array( 'default' => esc_html__( 'Nutrient Dense', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val2_title', array( 'label' => esc_html__( 'Pillar 2 Title', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val2_desc', array( 'default' => esc_html__( 'Our recipes prioritize whole-food ingredients packed with vitamins, healthy fats, fiber, and clean energy.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_val2_desc', array( 'label' => esc_html__( 'Pillar 2 Description', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// Value 3
	$wp_customize->add_setting( 'dsr_about_val3_icon', array( 'default' => '⏱', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val3_icon', array( 'label' => esc_html__( 'Pillar 3 Icon Emoji', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val3_title', array( 'default' => esc_html__( 'Easy Preparation', DSR_TEXT ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'dsr_about_val3_title', array( 'label' => esc_html__( 'Pillar 3 Title', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'text' ) );
	$wp_customize->add_setting( 'dsr_about_val3_desc', array( 'default' => esc_html__( 'Clear instructions, simple prep times, and accessible supermarket ingredients for busy everyday cooks.', DSR_TEXT ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'dsr_about_val3_desc', array( 'label' => esc_html__( 'Pillar 3 Description', DSR_TEXT ), 'section' => 'dsr_about_page_opts', 'type' => 'textarea' ) );

	// =========================================================================
	// SECTION: About Strip
	// =========================================================================
	$wp_customize->add_section(
		'dsr_about',
		array(
			'title'    => esc_html__( 'About Section (Homepage)', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 20,
		)
	);

	$wp_customize->add_setting(
		'dsr_about_image',
		array(
			'default'           => '',
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'dsr_about_image',
			array(
				'label'     => esc_html__( 'About Section Image', DSR_TEXT ),
				'section'   => 'dsr_about',
				'mime_type' => 'image',
			)
		)
	);

	$wp_customize->add_setting(
		'dsr_about_heading',
		array(
			'default'           => esc_html__( 'Welcome to Daily Salad Recipes', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_about_heading',
		array(
			'label'   => esc_html__( 'About Heading', DSR_TEXT ),
			'section' => 'dsr_about',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'dsr_about_text',
		array(
			'default'           => esc_html__( 'Daily Salad Recipes is a recipe website dedicated to making fresh, delicious salads easier to prepare at home. Explore simple green salads, vegetable salads, chicken salads, pasta salads, potato salads, high-protein meals, and homemade salad dressings for everyday cooking. Whether you\'re looking for a quick lunch, a healthy side dish, or a new salad to try, you\'ll find plenty of recipes to explore.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_about_text',
		array(
			'label'   => esc_html__( 'About Text', DSR_TEXT ),
			'section' => 'dsr_about',
			'type'    => 'textarea',
		)
	);

	$wp_customize->add_setting(
		'dsr_about_btn_text',
		array(
			'default'           => esc_html__( 'ABOUT DAILY SALAD RECIPES', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_about_btn_text',
		array(
			'label'   => esc_html__( 'About Button Text', DSR_TEXT ),
			'section' => 'dsr_about',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'dsr_about_btn_url',
		array(
			'default'           => '/about/',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_about_btn_url',
		array(
			'label'   => esc_html__( 'About Button URL', DSR_TEXT ),
			'section' => 'dsr_about',
			'type'    => 'url',
		)
	);

	// =========================================================================
	// SECTION: Newsletter
	// =========================================================================
	$wp_customize->add_section(
		'dsr_newsletter',
		array(
			'title'    => esc_html__( 'Newsletter Section', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'dsr_newsletter_heading',
		array(
			'default'           => esc_html__( 'Fresh Recipes in Your Inbox', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_newsletter_heading',
		array(
			'label'   => esc_html__( 'Newsletter Heading', DSR_TEXT ),
			'section' => 'dsr_newsletter',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'dsr_newsletter_text',
		array(
			'default'           => esc_html__( 'Get fresh salad recipes, healthy meal ideas, and delicious inspiration delivered straight to your inbox.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_newsletter_text',
		array(
			'label'   => esc_html__( 'Newsletter Description', DSR_TEXT ),
			'section' => 'dsr_newsletter',
			'type'    => 'textarea',
		)
	);

	$wp_customize->add_setting(
		'dsr_newsletter_image',
		array(
			'default'           => '',
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'dsr_newsletter_image',
			array(
				'label'     => esc_html__( 'Newsletter Side Image', DSR_TEXT ),
				'section'   => 'dsr_newsletter',
				'mime_type' => 'image',
			)
		)
	);

	// =========================================================================
	// SECTION: Social Links
	// =========================================================================
	$wp_customize->add_section(
		'dsr_social',
		array(
			'title'    => esc_html__( 'Social Links', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 40,
		)
	);

	$social_networks = array(
		'instagram' => array( 'label' => esc_html__( 'Instagram URL', DSR_TEXT ), 'default' => 'https://instagram.com' ),
		'pinterest' => array( 'label' => esc_html__( 'Pinterest URL', DSR_TEXT ), 'default' => 'https://pinterest.com' ),
		'facebook'  => array( 'label' => esc_html__( 'Facebook URL', DSR_TEXT ), 'default' => 'https://facebook.com' ),
		'youtube'   => array( 'label' => esc_html__( 'YouTube URL', DSR_TEXT ), 'default' => 'https://youtube.com' ),
		'tiktok'    => array( 'label' => esc_html__( 'TikTok URL', DSR_TEXT ), 'default' => 'https://tiktok.com' ),
	);

	foreach ( $social_networks as $key => $data ) {
		$wp_customize->add_setting(
			'dsr_social_' . $key,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'dsr_social_' . $key,
			array(
				'label'   => $data['label'],
				'section' => 'dsr_social',
				'type'    => 'url',
			)
		);
	}

	// =========================================================================
	// SECTION: Footer
	// =========================================================================
	$wp_customize->add_section(
		'dsr_footer',
		array(
			'title'    => esc_html__( 'Footer Settings', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 50,
		)
	);

	$wp_customize->add_setting(
		'dsr_footer_description',
		array(
			'default'           => esc_html__( 'Daily Salad Recipes: Easy & Healthy Salad Ideas. Fresh salad recipes for every day. Healthy, delicious, and simple to make.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_footer_description',
		array(
			'label'   => esc_html__( 'Footer Description', DSR_TEXT ),
			'section' => 'dsr_footer',
			'type'    => 'textarea',
		)
	);

	// =========================================================================
	// HELPER: Category Choices
	// =========================================================================
	$cat_choices = array( 0 => esc_html__( '— All / Latest —', DSR_TEXT ) );
	$categories  = get_categories( array( 'hide_empty' => false ) );
	if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
		foreach ( $categories as $cat ) {
			$cat_choices[ $cat->term_id ] = $cat->name;
		}
	}

	// =========================================================================
	// SECTION: Category Showcase 1
	// =========================================================================
	$wp_customize->add_section(
		'dsr_showcase_1_section',
		array(
			'title'    => esc_html__( 'Category Showcase 1', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 35,
		)
	);

	// Enable Showcase 1
	$wp_customize->add_setting(
		'dsr_showcase_enable_1',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_enable_1',
		array(
			'label'   => esc_html__( 'Enable Showcase 1', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'checkbox',
		)
	);

	// Category 1 Picker
	$wp_customize->add_setting(
		'dsr_showcase_cat_1',
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_cat_1',
		array(
			'label'   => esc_html__( 'Select Category', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'select',
			'choices' => $cat_choices,
		)
	);

	// Showcase 1 Eyebrow
	$wp_customize->add_setting(
		'dsr_showcase_eyebrow_1',
		array(
			'default'           => esc_html__( 'FRESH & NOURISHING', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_eyebrow_1',
		array(
			'label'   => esc_html__( 'Eyebrow Text', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'text',
		)
	);

	// Showcase 1 Title
	$wp_customize->add_setting(
		'dsr_showcase_title_1',
		array(
			'default'           => esc_html__( 'Healthy Salad Recipes', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_title_1',
		array(
			'label'   => esc_html__( 'Section Title', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'text',
		)
	);

	// Showcase 1 Subtitle
	$wp_customize->add_setting(
		'dsr_showcase_subtitle_1',
		array(
			'default'           => esc_html__( 'Fresh and satisfying salads for everyday meals.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_subtitle_1',
		array(
			'label'   => esc_html__( 'Subtitle', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'textarea',
		)
	);

	// Showcase 1 Button Text
	$wp_customize->add_setting(
		'dsr_showcase_btn_text_1',
		array(
			'default'           => esc_html__( 'EXPLORE HEALTHY SALADS', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_btn_text_1',
		array(
			'label'   => esc_html__( 'Button Link Text', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'text',
		)
	);

	// Showcase 1 Button URL
	$wp_customize->add_setting(
		'dsr_showcase_btn_url_1',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_btn_url_1',
		array(
			'label'   => esc_html__( 'Custom Button Link URL', DSR_TEXT ),
			'section' => 'dsr_showcase_1_section',
			'type'    => 'url',
		)
	);

	// =========================================================================
	// SECTION: Category Showcase 2
	// =========================================================================
	$wp_customize->add_section(
		'dsr_showcase_2_section',
		array(
			'title'    => esc_html__( 'Category Showcase 2', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 36,
		)
	);

	// Enable Showcase 2
	$wp_customize->add_setting(
		'dsr_showcase_enable_2',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_enable_2',
		array(
			'label'   => esc_html__( 'Enable Showcase 2', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'checkbox',
		)
	);

	// Category 2 Picker
	$wp_customize->add_setting(
		'dsr_showcase_cat_2',
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_cat_2',
		array(
			'label'   => esc_html__( 'Select Category', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'select',
			'choices' => $cat_choices,
		)
	);

	// Showcase 2 Eyebrow
	$wp_customize->add_setting(
		'dsr_showcase_eyebrow_2',
		array(
			'default'           => esc_html__( 'FILLING & FLAVORFUL', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_eyebrow_2',
		array(
			'label'   => esc_html__( 'Eyebrow Text', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'text',
		)
	);

	// Showcase 2 Title
	$wp_customize->add_setting(
		'dsr_showcase_title_2',
		array(
			'default'           => esc_html__( 'Easy Chicken Salad Recipes', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_title_2',
		array(
			'label'   => esc_html__( 'Section Title', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'text',
		)
	);

	// Showcase 2 Subtitle
	$wp_customize->add_setting(
		'dsr_showcase_subtitle_2',
		array(
			'default'           => esc_html__( 'Flavorful chicken salads for quick and satisfying meals.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_subtitle_2',
		array(
			'label'   => esc_html__( 'Subtitle', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'textarea',
		)
	);

	// Showcase 2 Button Text
	$wp_customize->add_setting(
		'dsr_showcase_btn_text_2',
		array(
			'default'           => esc_html__( 'EXPLORE CHICKEN SALADS', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_btn_text_2',
		array(
			'label'   => esc_html__( 'Button Link Text', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'text',
		)
	);

	// Showcase 2 Button URL
	$wp_customize->add_setting(
		'dsr_showcase_btn_url_2',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_showcase_btn_url_2',
		array(
			'label'   => esc_html__( 'Custom Button Link URL', DSR_TEXT ),
			'section' => 'dsr_showcase_2_section',
			'type'    => 'url',
		)
	);

	// =========================================================================
	// SECTION: Contact Page Options
	// =========================================================================
	$wp_customize->add_section(
		'dsr_contact_page_opts',
		array(
			'title'    => esc_html__( 'Contact Page Settings', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 45,
		)
	);

	// Hero Eyebrow
	$wp_customize->add_setting(
		'dsr_contact_hero_eyebrow',
		array(
			'default'           => esc_html__( 'Let\'s Connect', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_hero_eyebrow',
		array(
			'label'   => esc_html__( 'Hero Eyebrow Text', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'text',
		)
	);

	// Hero Title
	$wp_customize->add_setting(
		'dsr_contact_hero_title',
		array(
			'default'           => esc_html__( 'We Would Love to Hear From You', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_hero_title',
		array(
			'label'   => esc_html__( 'Hero Title', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'text',
		)
	);

	// Hero Subtitle
	$wp_customize->add_setting(
		'dsr_contact_hero_subtitle',
		array(
			'default'           => esc_html__( 'Have a question about a recipe, feedback, or a partnership inquiry? Drop us a message below.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_hero_subtitle',
		array(
			'label'   => esc_html__( 'Hero Subtitle', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'textarea',
		)
	);

	// Contact Email
	$wp_customize->add_setting(
		'dsr_contact_email_opt',
		array(
			'default'           => 'hello@dailysaladrecipes.com',
			'sanitize_callback' => 'sanitize_email',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_email_opt',
		array(
			'label'   => esc_html__( 'Contact Email Address', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'email',
		)
	);

	// Contact Location
	$wp_customize->add_setting(
		'dsr_contact_location_opt',
		array(
			'default'           => 'Daily Salad Recipes Kitchen & Studio',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_location_opt',
		array(
			'label'   => esc_html__( 'Location / Address', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'text',
		)
	);

	// Contact Partnerships Email
	$wp_customize->add_setting(
		'dsr_contact_partnerships_email',
		array(
			'default'           => 'partnerships@dailysaladrecipes.com',
			'sanitize_callback' => 'sanitize_email',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'dsr_contact_partnerships_email',
		array(
			'label'   => esc_html__( 'Partnerships Email', DSR_TEXT ),
			'section' => 'dsr_contact_page_opts',
			'type'    => 'email',
		)
	);

	// =========================================================================
	// SECTION: Colors
	// =========================================================================
	$wp_customize->add_section(
		'dsr_colors',
		array(
			'title'    => esc_html__( 'Theme Colors', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 60,
		)
	);

	$colors = array(
		'dsr_color_primary'   => array(
			'label'   => esc_html__( 'Primary (Deep Green)', DSR_TEXT ),
			'default' => '#173F35',
		),
		'dsr_color_secondary' => array(
			'label'   => esc_html__( 'Secondary (Olive Green)', DSR_TEXT ),
			'default' => '#71845B',
		),
		'dsr_color_accent'    => array(
			'label'   => esc_html__( 'Accent (Terracotta)', DSR_TEXT ),
			'default' => '#C96F4A',
		),
		'dsr_color_bg'        => array(
			'label'   => esc_html__( 'Background (Ivory)', DSR_TEXT ),
			'default' => '#FAF8F3',
		),
		'dsr_color_text'      => array(
			'label'   => esc_html__( 'Main Text (Charcoal)', DSR_TEXT ),
			'default' => '#202522',
		),
	);

	foreach ( $colors as $key => $data ) {
		$wp_customize->add_setting(
			$key,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'postMessage',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$key,
				array(
					'label'   => $data['label'],
					'section' => 'dsr_colors',
				)
			)
		);
	}

	// =========================================================================
	// SECTION: Products Page
	// =========================================================================
	$wp_customize->add_section(
		'dsr_products_page',
		array(
			'title'    => esc_html__( 'Products Page', DSR_TEXT ),
			'panel'    => 'dsr_theme_options',
			'priority' => 55,
		)
	);

	// ---- Header Intro Section ----
	$wp_customize->add_setting(
		'dsr_products_hero_title',
		array(
			'default'           => esc_html__( 'Products', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_products_hero_title',
		array(
			'label'       => esc_html__( 'Products Page Title (H1)', DSR_TEXT ),
			'description' => esc_html__( 'The main page title displayed in the header banner.', DSR_TEXT ),
			'section'     => 'dsr_products_page',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'dsr_products_hero_subtitle',
		array(
			'default'           => esc_html__( 'Simple tools and guides to make meal planning, healthy cooking, and everyday eating easier.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_products_hero_subtitle',
		array(
			'label'       => esc_html__( 'Products Page Description / Subtitle', DSR_TEXT ),
			'description' => esc_html__( 'The description paragraph displayed below the title in the header banner.', DSR_TEXT ),
			'section'     => 'dsr_products_page',
			'type'        => 'textarea',
		)
	);

	// ---- Currency Symbol ----
	$wp_customize->add_setting(
		'dsr_currency_symbol',
		array(
			'default'           => '$',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'dsr_currency_symbol',
		array(
			'label'       => esc_html__( 'Currency Symbol', DSR_TEXT ),
			'description' => esc_html__( 'Currency symbol displayed next to product prices (e.g. $, €, £, USD).', DSR_TEXT ),
			'section'     => 'dsr_products_page',
			'type'        => 'text',
		)
	);

	// ---- SEO Meta ----
	$wp_customize->add_setting(
		'dsr_products_seo_title',
		array(
			'default'           => esc_html__( 'Products — Recipe E-Books & Guides | Daily Salad Recipes', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_products_seo_title',
		array(
			'label'       => esc_html__( 'SEO Browser Title Tag', DSR_TEXT ),
			'section'     => 'dsr_products_page',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'dsr_products_seo_description',
		array(
			'default'           => esc_html__( 'Shop our curated collection of digital salad recipe e-books, healthy meal planning guides, and cooking resources.', DSR_TEXT ),
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'dsr_products_seo_description',
		array(
			'label'       => esc_html__( 'SEO Meta Description', DSR_TEXT ),
			'section'     => 'dsr_products_page',
			'type'        => 'textarea',
		)
	);
}
add_action( 'customize_register', 'dsr_customizer' );

// =========================================================================
// Customizer live preview JS
// =========================================================================
function dsr_customizer_preview_js() {
	wp_enqueue_script(
		'dsr-customizer-preview',
		DSR_URI . '/assets/js/customizer-preview.js',
		array( 'customize-preview' ),
		DSR_VERSION,
		true
	);
}
add_action( 'customize_preview_init', 'dsr_customizer_preview_js' );

// =========================================================================
// Output dynamic CSS from Customizer color & card settings
// =========================================================================
function dsr_customizer_css() {
	$primary   = get_theme_mod( 'dsr_color_primary', '#173F35' );
	$secondary = get_theme_mod( 'dsr_color_secondary', '#71845B' );
	$accent    = get_theme_mod( 'dsr_color_accent', '#C96F4A' );
	$bg        = get_theme_mod( 'dsr_color_bg', '#FAF8F3' );
	$text      = get_theme_mod( 'dsr_color_text', '#202522' );

	// Card customization options
	$card_padding = get_theme_mod( 'dsr_card_padding', 'standard' );
	$card_ratio   = get_theme_mod( 'dsr_card_aspect_ratio', '4/5' );
	$card_bg      = get_theme_mod( 'dsr_card_bg_color', '#ffffff' );
	$card_shadow  = get_theme_mod( 'dsr_card_shadow', 'soft' );

	$padding_val = '1.25rem';
	if ( 'compact' === $card_padding ) {
		$padding_val = '0.75rem';
	} elseif ( 'spacious' === $card_padding ) {
		$padding_val = '1.75rem';
	}

	$ratio_val = '4 / 5';
	if ( '1/1' === $card_ratio ) {
		$ratio_val = '1 / 1';
	} elseif ( '3/4' === $card_ratio ) {
		$ratio_val = '3 / 4';
	}

	$shadow_val = '0 4px 16px rgba(0,0,0,0.06)';
	if ( 'flat' === $card_shadow ) {
		$shadow_val = 'none';
	} elseif ( 'elevated' === $card_shadow ) {
		$shadow_val = '0 16px 40px rgba(23,63,53,0.14)';
	}

	$css = ":root{
		--color-primary:" . sanitize_hex_color( $primary ) . ";
		--color-secondary:" . sanitize_hex_color( $secondary ) . ";
		--color-accent:" . sanitize_hex_color( $accent ) . ";
		--color-bg:" . sanitize_hex_color( $bg ) . ";
		--color-text:" . sanitize_hex_color( $text ) . ";
		--dsr-card-padding:" . esc_attr( $padding_val ) . ";
		--dsr-card-ratio:" . esc_attr( $ratio_val ) . ";
		--dsr-card-bg: transparent;
		--dsr-card-shadow: none;
	}";

	wp_add_inline_style( 'dsr-main', $css );
}
add_action( 'wp_enqueue_scripts', 'dsr_customizer_css', 20 );

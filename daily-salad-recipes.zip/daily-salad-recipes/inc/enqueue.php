<?php
/**
 * Daily Salad Recipes — Enqueue Scripts & Styles
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function dsr_enqueue_assets() {

	// -------------------------------------------------------------------------
	// Google Fonts — Cormorant Garamond (headings) + DM Sans (body)
	// -------------------------------------------------------------------------
	wp_enqueue_style(
		'dsr-google-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap',
		array(),
		null
	);

	// -------------------------------------------------------------------------
	// Theme root style.css (Contains Critical Sub-Menu Fix & 4:5 Aspect Ratio)
	// -------------------------------------------------------------------------
	wp_enqueue_style(
		'dsr-style',
		get_stylesheet_uri(),
		array(),
		DSR_VERSION
	);

	// -------------------------------------------------------------------------
	// Main stylesheet
	// -------------------------------------------------------------------------
	wp_enqueue_style(
		'dsr-main',
		DSR_URI . '/assets/css/main.css',
		array( 'dsr-google-fonts', 'dsr-style' ),
		DSR_VERSION
	);

	// -------------------------------------------------------------------------
	// Recipe-specific styles — only on singular posts/recipes & archives
	// -------------------------------------------------------------------------
	if ( is_singular( 'post' ) || is_singular( 'recipe' ) || is_singular() ) {
		wp_enqueue_style(
			'dsr-recipe',
			DSR_URI . '/assets/css/recipe.css',
			array( 'dsr-main' ),
			DSR_VERSION
		);
	}

	// -------------------------------------------------------------------------
	// Product-specific styles — on product archives & single products
	// -------------------------------------------------------------------------
	if ( is_post_type_archive( 'product' ) || is_singular( 'product' ) || is_tax( 'product_category' ) ) {
		wp_enqueue_style(
			'dsr-product',
			DSR_URI . '/assets/css/product.css',
			array( 'dsr-main' ),
			DSR_VERSION
		);
	}

	// -------------------------------------------------------------------------
	// Main JS — deferred, in footer
	// -------------------------------------------------------------------------
	wp_enqueue_script(
		'dsr-main',
		DSR_URI . '/assets/js/main.js',
		array(),
		DSR_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	// -------------------------------------------------------------------------
	// Recipe JS — only on recipe/post pages
	// -------------------------------------------------------------------------
	if ( is_singular( 'post' ) || is_singular( 'recipe' ) || is_singular() ) {
		wp_enqueue_script(
			'dsr-recipe',
			DSR_URI . '/assets/js/recipe.js',
			array(),
			DSR_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	// -------------------------------------------------------------------------
	// Localize script data.
	// -------------------------------------------------------------------------
	wp_localize_script(
		'dsr-main',
		'DSR',
		array(
			'ajaxUrl'  => esc_url( admin_url( 'admin-ajax.php' ) ),
			'nonce'    => wp_create_nonce( 'dsr_nonce' ),
			'homeUrl'  => esc_url( home_url( '/' ) ),
			'themeUri' => esc_url( DSR_URI ),
			'i18n'     => array(
				'copied'       => esc_html__( 'Link copied!', DSR_TEXT ),
				'copyFailed'   => esc_html__( 'Could not copy link.', DSR_TEXT ),
				'menuOpen'     => esc_html__( 'Open menu', DSR_TEXT ),
				'menuClose'    => esc_html__( 'Close menu', DSR_TEXT ),
				'searchOpen'   => esc_html__( 'Open search', DSR_TEXT ),
				'searchClose'  => esc_html__( 'Close search', DSR_TEXT ),
			),
		)
	);

	// -------------------------------------------------------------------------
	// Comments — only where needed.
	// -------------------------------------------------------------------------
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dsr_enqueue_assets' );

// -------------------------------------------------------------------------
// Editor styles
// -------------------------------------------------------------------------
function dsr_block_editor_assets() {
	wp_enqueue_style(
		'dsr-google-fonts-editor',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap',
		array(),
		null
	);
}
add_action( 'enqueue_block_editor_assets', 'dsr_block_editor_assets' );

/**
 * Critical Inline Head Styles — Guarantees sub-menu dropdown fix & 4:5 image ratio even if external CSS files are cached by plugins or browser.
 */
function dsr_critical_head_styles() {
	echo '<style id="dsr-critical-head-styles">
		.site-header .sub-menu, .primary-nav .sub-menu, .main-navigation .sub-menu, .nav-menu .sub-menu, .menu .sub-menu, ul.sub-menu { display: none !important; position: absolute !important; top: 100% !important; left: 0 !important; z-index: 99999 !important; background: #ffffff !important; border: 1px solid rgba(0,0,0,0.08) !important; border-radius: 8px !important; box-shadow: 0 16px 36px rgba(0,0,0,0.15) !important; min-width: 230px !important; margin: 0 !important; padding: 8px 0 !important; list-style: none !important; float: none !important; }
		.site-header li:hover > .sub-menu, .primary-nav li:hover > .sub-menu, .main-navigation li:hover > .sub-menu, .nav-menu li:hover > .sub-menu, .menu li:hover > .sub-menu, .site-header li:focus-within > .sub-menu, .primary-nav li:focus-within > .sub-menu { display: block !important; }
		.site-header .sub-menu li, .primary-nav .sub-menu li, .main-navigation .sub-menu li, ul.sub-menu li { display: block !important; width: 100% !important; margin: 0 !important; padding: 0 !important; float: none !important; }
		.site-header .sub-menu li a, .primary-nav .sub-menu li a, .main-navigation .sub-menu li a, ul.sub-menu li a { display: block !important; padding: 10px 20px !important; color: #1E3A2B !important; font-size: 0.82rem !important; font-weight: 600 !important; text-transform: uppercase !important; text-decoration: none !important; white-space: nowrap !important; transition: all 0.2s ease !important; border-radius: 0 !important; }
		.site-header .sub-menu li a:hover, .primary-nav .sub-menu li a:hover, .main-navigation .sub-menu li a:hover { background: #E8F5E9 !important; color: #2D5A3C !important; padding-left: 24px !important; }
		.site-header li, .primary-nav li, .main-navigation li { position: relative !important; }
		:root { --dsr-card-bg: transparent !important; }
		.recipe-card, .recipe-card__body, .recipe-card__title, .dsr-post, .dsr-product-card, .dsr-product-card__body, .dsr-product-card__footer { background: transparent !important; background-color: transparent !important; border-radius: 0 !important; box-shadow: none !important; border: none !important; }
		.recipe-card:hover, .dsr-post:hover, .dsr-product-card:hover { box-shadow: none !important; background: transparent !important; }
		.recipe-card__image-wrap { position: relative !important; width: 100% !important; aspect-ratio: 4 / 5 !important; overflow: hidden !important; background: #E8F5E9 !important; flex-shrink: 0 !important; display: block !important; border-radius: 0 !important; }
		.recipe-card__image-wrap img, .recipe-card__image-wrap .wp-post-image, .recipe-card__image-wrap .dsr-placeholder-img { width: 100% !important; height: 100% !important; max-height: none !important; min-height: 100% !important; aspect-ratio: 4 / 5 !important; object-fit: cover !important; object-position: center !important; display: block !important; border-radius: 0 !important; }
	</style>';
}
add_action( 'wp_head', 'dsr_critical_head_styles', 1 );

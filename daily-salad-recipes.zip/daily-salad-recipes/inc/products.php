<?php
/**
 * Daily Salad Recipes — Products Custom Post Type & Meta System
 *
 * Registers the 'product' custom post type, product_category taxonomy,
 * admin custom fields (Price, Purchase URL, Short Description, Badge),
 * and admin column customizations.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --------------------------------------------------------------------------
// 1. Register Custom Post Type: Products
// --------------------------------------------------------------------------
function dsr_register_products_cpt() {

	$labels = array(
		'name'                  => _x( 'Products', 'Post Type General Name', DSR_TEXT ),
		'singular_name'         => _x( 'Product', 'Post Type Singular Name', DSR_TEXT ),
		'menu_name'             => __( 'Products', DSR_TEXT ),
		'name_admin_bar'        => __( 'Product', DSR_TEXT ),
		'archives'              => __( 'Product Archives', DSR_TEXT ),
		'attributes'            => __( 'Product Attributes', DSR_TEXT ),
		'parent_item_colon'     => __( 'Parent Product:', DSR_TEXT ),
		'all_items'             => __( 'All Products', DSR_TEXT ),
		'add_new_item'          => __( 'Add New Product', DSR_TEXT ),
		'add_new'               => __( 'Add New', DSR_TEXT ),
		'new_item'              => __( 'New Product', DSR_TEXT ),
		'edit_item'             => __( 'Edit Product', DSR_TEXT ),
		'update_item'           => __( 'Update Product', DSR_TEXT ),
		'view_item'             => __( 'View Product', DSR_TEXT ),
		'view_items'            => __( 'View Products', DSR_TEXT ),
		'search_items'          => __( 'Search Products', DSR_TEXT ),
		'not_found'             => __( 'No products found', DSR_TEXT ),
		'not_found_in_trash'    => __( 'No products found in Trash', DSR_TEXT ),
		'featured_image'        => __( 'Product Image', DSR_TEXT ),
		'set_featured_image'    => __( 'Set product image', DSR_TEXT ),
		'remove_featured_image' => __( 'Remove product image', DSR_TEXT ),
		'use_featured_image'    => __( 'Use as product image', DSR_TEXT ),
		'insert_into_item'      => __( 'Insert into product', DSR_TEXT ),
		'uploaded_to_this_item' => __( 'Uploaded to this product', DSR_TEXT ),
		'items_list'            => __( 'Products list', DSR_TEXT ),
		'items_list_navigation' => __( 'Products list navigation', DSR_TEXT ),
		'filter_items_list'     => __( 'Filter products list', DSR_TEXT ),
	);

	$args = array(
		'label'                 => __( 'Product', DSR_TEXT ),
		'description'           => __( 'Digital products, recipe e-books, and meal planning guides.', DSR_TEXT ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'taxonomies'            => array( 'product_category' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-cart',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'rewrite'               => array(
			'slug'       => 'products',
			'with_front' => false,
		),
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
		'show_in_rest'          => true,
	);

	register_post_type( 'product', $args );
}
add_action( 'init', 'dsr_register_products_cpt', 0 );

// --------------------------------------------------------------------------
// 2. Register Taxonomy: Product Categories
// --------------------------------------------------------------------------
function dsr_register_products_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Product Categories', 'Taxonomy General Name', DSR_TEXT ),
		'singular_name'              => _x( 'Product Category', 'Taxonomy Singular Name', DSR_TEXT ),
		'menu_name'                  => __( 'Categories', DSR_TEXT ),
		'all_items'                  => __( 'All Categories', DSR_TEXT ),
		'parent_item'                => __( 'Parent Category', DSR_TEXT ),
		'parent_item_colon'          => __( 'Parent Category:', DSR_TEXT ),
		'new_item_name'              => __( 'New Category Name', DSR_TEXT ),
		'add_new_item'               => __( 'Add New Category', DSR_TEXT ),
		'edit_item'                  => __( 'Edit Category', DSR_TEXT ),
		'update_item'                => __( 'Update Category', DSR_TEXT ),
		'view_item'                  => __( 'View Category', DSR_TEXT ),
		'separate_items_with_commas' => __( 'Separate categories with commas', DSR_TEXT ),
		'add_or_remove_items'        => __( 'Add or remove categories', DSR_TEXT ),
		'choose_from_most_used'      => __( 'Choose from the most used', DSR_TEXT ),
		'popular_items'              => __( 'Popular Categories', DSR_TEXT ),
		'search_items'               => __( 'Search Categories', DSR_TEXT ),
		'not_found'                  => __( 'Not Found', DSR_TEXT ),
		'no_terms'                   => __( 'No categories', DSR_TEXT ),
		'items_list'                 => __( 'Categories list', DSR_TEXT ),
		'items_list_navigation'    => __( 'Categories list navigation', DSR_TEXT ),
	);

	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => array(
			'slug'       => 'product-category',
			'with_front' => false,
		),
		'show_in_rest'               => true,
	);

	register_taxonomy( 'product_category', array( 'product' ), $args );
}
add_action( 'init', 'dsr_register_products_taxonomy', 0 );

// --------------------------------------------------------------------------
// 3. Custom Meta Box for Product Fields (Price, Purchase URL, Short Desc, Badge)
// --------------------------------------------------------------------------
function dsr_add_product_meta_box() {
	add_meta_box(
		'dsr_product_details',
		__( 'Product Information', DSR_TEXT ),
		'dsr_render_product_meta_box',
		'product',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'dsr_add_product_meta_box' );

function dsr_render_product_meta_box( $post ) {
	wp_nonce_field( 'dsr_save_product_meta', 'dsr_product_meta_nonce' );

	$price        = get_post_meta( $post->ID, '_dsr_product_price', true );
	$purchase_url = get_post_meta( $post->ID, '_dsr_product_purchase_url', true );
	$short_desc   = get_post_meta( $post->ID, '_dsr_product_short_desc', true );
	$badge        = get_post_meta( $post->ID, '_dsr_product_badge', true );
	?>
	<style>
		.dsr-meta-field { margin-bottom: 18px; }
		.dsr-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; color: #173F35; }
		.dsr-meta-field input[type="text"],
		.dsr-meta-field input[type="url"],
		.dsr-meta-field textarea { width: 100%; padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
		.dsr-meta-field p.description { margin-top: 4px; color: #666; font-style: italic; font-size: 12px; }
		.dsr-meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
		@media (max-width: 600px) { .dsr-meta-grid { grid-template-columns: 1fr; } }
	</style>

	<div class="dsr-meta-grid">
		<div class="dsr-meta-field">
			<label for="dsr_product_price"><?php esc_html_e( 'Price ($)', DSR_TEXT ); ?></label>
			<input type="text" id="dsr_product_price" name="dsr_product_price" value="<?php echo esc_attr( $price ); ?>" placeholder="<?php esc_attr_e( 'e.g. $14.99 or Free', DSR_TEXT ); ?>" />
			<p class="description"><?php esc_html_e( 'Enter the price to display on cards and single product page.', DSR_TEXT ); ?></p>
		</div>

		<div class="dsr-meta-field">
			<label for="dsr_product_badge"><?php esc_html_e( 'Badge / Label (Optional)', DSR_TEXT ); ?></label>
			<input type="text" id="dsr_product_badge" name="dsr_product_badge" value="<?php echo esc_attr( $badge ); ?>" placeholder="<?php esc_attr_e( 'e.g. Bestseller, New, E-Book', DSR_TEXT ); ?>" />
			<p class="description"><?php esc_html_e( 'Highlighted tag displayed on product card image.', DSR_TEXT ); ?></p>
		</div>
	</div>

	<div class="dsr-meta-field">
		<label for="dsr_product_purchase_url"><?php esc_html_e( 'External Purchase URL *', DSR_TEXT ); ?></label>
		<input type="url" id="dsr_product_purchase_url" name="dsr_product_purchase_url" value="<?php echo esc_url( $purchase_url ); ?>" placeholder="https://gumroad.com/l/your-ebook" />
		<p class="description"><?php esc_html_e( 'The checkout link customers will be sent to when clicking the Buy/Purchase button.', DSR_TEXT ); ?></p>
	</div>

	<div class="dsr-meta-field">
		<label for="dsr_product_short_desc"><?php esc_html_e( 'Short Description', DSR_TEXT ); ?></label>
		<textarea id="dsr_product_short_desc" name="dsr_product_short_desc" rows="3" placeholder="<?php esc_attr_e( 'A brief 1-2 sentence overview of what this product offers...', DSR_TEXT ); ?>"><?php echo esc_textarea( $short_desc ); ?></textarea>
		<p class="description"><?php esc_html_e( 'Displayed on product cards in grid views. Falls back to excerpt if blank.', DSR_TEXT ); ?></p>
	</div>
	<?php
}

function dsr_save_product_meta( $post_id ) {
	if ( ! isset( $_POST['dsr_product_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['dsr_product_meta_nonce'] ), 'dsr_save_product_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['dsr_product_price'] ) ) {
		update_post_meta( $post_id, '_dsr_product_price', sanitize_text_field( wp_unslash( $_POST['dsr_product_price'] ) ) );
	}

	if ( isset( $_POST['dsr_product_purchase_url'] ) ) {
		update_post_meta( $post_id, '_dsr_product_purchase_url', esc_url_raw( wp_unslash( $_POST['dsr_product_purchase_url'] ) ) );
	}

	if ( isset( $_POST['dsr_product_short_desc'] ) ) {
		update_post_meta( $post_id, '_dsr_product_short_desc', sanitize_textarea_field( wp_unslash( $_POST['dsr_product_short_desc'] ) ) );
	}

	if ( isset( $_POST['dsr_product_badge'] ) ) {
		update_post_meta( $post_id, '_dsr_product_badge', sanitize_text_field( wp_unslash( $_POST['dsr_product_badge'] ) ) );
	}
}
add_action( 'save_post_product', 'dsr_save_product_meta' );

// --------------------------------------------------------------------------
// 4. Helper Getter Functions
// --------------------------------------------------------------------------
function dsr_get_product_price( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$price   = get_post_meta( $post_id, '_dsr_product_price', true );

	if ( empty( $price ) && $price !== '0' ) {
		return '';
	}

	$price_trimmed   = trim( (string) $price );
	$currency_symbol = get_theme_mod( 'dsr_currency_symbol', '$' );

	if ( is_numeric( $price_trimmed ) ) {
		$num = (float) $price_trimmed;
		if ( 0.0 === $num ) {
			return __( 'Free', DSR_TEXT );
		}
		return esc_html( $currency_symbol . number_format( $num, 2 ) );
	}

	// If price string doesn't contain $, €, £, ¥, ₹ or letters (e.g. USD, EUR)
	if ( ! preg_match( '/[\$\€\£\¥\₹\A-Za-z]/u', $price_trimmed ) ) {
		return esc_html( $currency_symbol . $price_trimmed );
	}

	return esc_html( $price_trimmed );
}

function dsr_get_product_purchase_url( $post_id = null ) {
	$post_id      = $post_id ? $post_id : get_the_ID();
	$purchase_url = get_post_meta( $post_id, '_dsr_product_purchase_url', true );
	return $purchase_url ? esc_url( $purchase_url ) : get_permalink( $post_id );
}

function dsr_get_product_short_desc( $post_id = null ) {
	$post_id    = $post_id ? $post_id : get_the_ID();
	$short_desc = get_post_meta( $post_id, '_dsr_product_short_desc', true );

	if ( ! empty( $short_desc ) ) {
		return esc_html( $short_desc );
	}

	if ( has_excerpt( $post_id ) ) {
		return esc_html( get_the_excerpt( $post_id ) );
	}

	return esc_html( wp_trim_words( get_post_field( 'post_content', $post_id ), 20, '&hellip;' ) );
}

function dsr_get_product_badge( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$badge   = get_post_meta( $post_id, '_dsr_product_badge', true );
	return $badge ? esc_html( $badge ) : '';
}

// --------------------------------------------------------------------------
// 5. Admin List Table Custom Columns
// --------------------------------------------------------------------------
function dsr_set_product_columns( $columns ) {
	$new_columns = array(
		'cb'           => $columns['cb'],
		'title'        => __( 'Title', DSR_TEXT ),
		'product_img'  => __( 'Image', DSR_TEXT ),
		'price'        => __( 'Price', DSR_TEXT ),
		'taxonomy-product_category' => __( 'Category', DSR_TEXT ),
		'purchase_url' => __( 'Purchase URL', DSR_TEXT ),
		'date'         => $columns['date'],
	);
	return $new_columns;
}
add_filter( 'manage_product_posts_columns', 'dsr_set_product_columns' );

function dsr_render_product_columns( $column, $post_id ) {
	switch ( $column ) {
		case 'product_img':
			if ( has_post_thumbnail( $post_id ) ) {
				echo get_the_post_thumbnail( $post_id, array( 50, 50 ), array( 'style' => 'border-radius:4px;object-fit:cover;' ) );
			} else {
				echo '<span style="color:#aaa;">' . esc_html__( 'No image', DSR_TEXT ) . '</span>';
			}
			break;

		case 'price':
			$price = dsr_get_product_price( $post_id );
			echo $price ? '<strong>' . esc_html( $price ) . '</strong>' : '&mdash;';
			break;

		case 'purchase_url':
			$url = get_post_meta( $post_id, '_dsr_product_purchase_url', true );
			if ( $url ) {
				echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( wp_parse_url( $url, PHP_URL_HOST ) ) . ' &rarr;</a>';
			} else {
				echo '<span style="color:#aaa;">' . esc_html__( 'Not set', DSR_TEXT ) . '</span>';
			}
			break;
	}
}
add_action( 'manage_product_posts_custom_column', 'dsr_render_product_columns', 10, 2 );

// --------------------------------------------------------------------------
// 6. Flush Rewrite Rules When Needed
// --------------------------------------------------------------------------

/**
 * Flush rewrite rules once when the product CPT is first registered.
 * Uses a transient flag so the flush only runs once (not on every page load).
 * After the first flush, it will not run again until the transient is deleted
 * (e.g. by re-saving permalinks, switching themes, or updating the theme).
 */
function dsr_products_maybe_flush_rewrites() {
	if ( ! get_option( 'dsr_products_rewrites_flushed' ) ) {
		flush_rewrite_rules();
		update_option( 'dsr_products_rewrites_flushed', true );
	}
}
add_action( 'init', 'dsr_products_maybe_flush_rewrites', 99 );

/**
 * Clear the flush flag on theme switch so it re-flushes on next load.
 */
function dsr_products_flush_on_switch() {
	delete_option( 'dsr_products_rewrites_flushed' );
}
add_action( 'after_switch_theme', 'dsr_products_flush_on_switch' );

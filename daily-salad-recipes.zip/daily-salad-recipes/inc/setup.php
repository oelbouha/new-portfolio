<?php
/**
 * Daily Salad Recipes — Theme Setup
 *
 * Registers theme supports, navigation menus, image sizes, and editor styles.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --------------------------------------------------------------------------
// after_setup_theme
// --------------------------------------------------------------------------
function dsr_setup() {

	// Make theme available for translation.
	load_theme_textdomain( DSR_TEXT, DSR_DIR . '/languages' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// Custom logo.
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 60,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
			'header-text' => array( 'site-title', 'site-description' ),
		)
	);

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Responsive embeds.
	add_theme_support( 'responsive-embeds' );

	// HTML5 markup.
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Post formats (if needed for editorial posts).
	add_theme_support( 'post-formats', array( 'aside', 'gallery', 'image', 'video' ) );

	// Automatic feed links.
	add_theme_support( 'automatic-feed-links' );

	// Editor styles.
	add_editor_style( 'assets/css/editor-style.css' );

	// Wide & full alignment in block editor.
	add_theme_support( 'align-wide' );

	// Custom background.
	add_theme_support(
		'custom-background',
		array(
			'default-color' => 'FAF8F3',
		)
	);

	// Starter content (shown when no content exists yet).
	add_theme_support(
		'starter-content',
		array(
			'nav_menus' => array(
				'primary' => array(
					'name'  => __( 'Primary Navigation', DSR_TEXT ),
					'items' => array(
						'link_home'       => array(),
						'page_about'      => array(),
						'link_recipes'    => array(
							'title' => __( 'Recipes', DSR_TEXT ),
							'url'   => '/recipes/',
						),
						'link_categories' => array(
							'title' => __( 'Categories', DSR_TEXT ),
							'url'   => '/recipe-categories/',
						),
						'link_products'   => array(
							'title' => __( 'Products', DSR_TEXT ),
							'url'   => '/products/',
						),
					),
				),
			),
		)
	);

	// --------------------------------------------------------------------------
	// Register Navigation Menus
	// --------------------------------------------------------------------------
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary Navigation', DSR_TEXT ),
			'footer'  => esc_html__( 'Footer Navigation', DSR_TEXT ),
			'legal'   => esc_html__( 'Legal Navigation', DSR_TEXT ),
		)
	);

	// --------------------------------------------------------------------------
	// Custom Image Sizes
	// --------------------------------------------------------------------------

	// Recipe card thumbnail — 4:5 portrait crop.
	add_image_size( 'dsr-card', 480, 600, true );

	// Recipe hero — large landscape.
	add_image_size( 'dsr-hero', 1400, 700, true );

	// Recipe feature — medium landscape.
	add_image_size( 'dsr-feature', 800, 500, true );

	// Category circular thumbnail.
	add_image_size( 'dsr-category', 300, 300, true );

	// Related recipe small card.
	add_image_size( 'dsr-related', 360, 450, true );

	// Wide editorial.
	add_image_size( 'dsr-wide', 1200, 500, true );

	// --------------------------------------------------------------------------
	// Content width
	// --------------------------------------------------------------------------
	global $content_width;
	if ( ! isset( $content_width ) ) {
		$content_width = 1400;
	}
}
add_action( 'after_setup_theme', 'dsr_setup' );

/**
 * Auto-create About & Contact pages if they don't exist and assign templates.
 */
function dsr_create_default_pages() {
	$about_page = get_page_by_path( 'about' );
	if ( ! $about_page ) {
		$about_id = wp_insert_post(
			array(
				'post_title'     => 'About Us',
				'post_name'      => 'about',
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'page_template'  => 'page-about.php',
			)
		);
		if ( $about_id ) {
			update_post_meta( $about_id, '_wp_page_template', 'page-about.php' );
		}
	} else {
		update_post_meta( $about_page->ID, '_wp_page_template', 'page-about.php' );
	}
}
add_action( 'after_switch_theme', 'dsr_create_default_pages' );

// --------------------------------------------------------------------------
// Add 'dsr-card' and custom sizes to the insert media dialog.
// --------------------------------------------------------------------------
function dsr_custom_image_sizes( $sizes ) {
	return array_merge(
		$sizes,
		array(
			'dsr-card'     => esc_html__( 'Recipe Card', DSR_TEXT ),
			'dsr-hero'     => esc_html__( 'Recipe Hero', DSR_TEXT ),
			'dsr-feature'  => esc_html__( 'Recipe Feature', DSR_TEXT ),
			'dsr-category' => esc_html__( 'Category Circle', DSR_TEXT ),
			'dsr-related'  => esc_html__( 'Related Recipe', DSR_TEXT ),
		)
	);
}
add_filter( 'image_size_names_choose', 'dsr_custom_image_sizes' );

// --------------------------------------------------------------------------
// Excerpt length & more.
// --------------------------------------------------------------------------
function dsr_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'dsr_excerpt_length' );

function dsr_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'dsr_excerpt_more' );

// --------------------------------------------------------------------------
// Body classes.
// --------------------------------------------------------------------------
function dsr_body_classes( $classes ) {
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}
	if ( is_singular( 'post' ) && has_post_thumbnail() ) {
		$classes[] = 'has-featured-image';
	}
	if ( is_front_page() ) {
		$classes[] = 'dsr-front-page';
	}
	if ( is_singular( 'post' ) || is_singular( 'recipe' ) ) {
		$classes[] = 'dsr-single-recipe';
	}
	return $classes;
}
add_filter( 'body_class', 'dsr_body_classes' );

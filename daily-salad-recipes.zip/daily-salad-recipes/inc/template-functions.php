<?php
/**
 * Daily Salad Recipes — Template Helper Functions
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==========================================================================
// SUPPRESS PAGE TITLES ON FRONTEND (for static WordPress pages only)
// ==========================================================================

/**
 * Remove the page title from the_title() output on the frontend
 * for standard WordPress pages (not posts, not products, not recipes).
 *
 * This only affects display output — admin, nav menus, SEO, and
 * wp_head title-tag remain untouched.
 */
function dsr_remove_page_title( $title, $id = null ) {
	// Only on the frontend, inside the loop, on singular pages.
	if ( is_admin() || ! in_the_loop() || ! is_page() ) {
		return $title;
	}

	// Only suppress for the main queried page object.
	if ( $id && (int) $id === (int) get_queried_object_id() ) {
		return '';
	}

	return $title;
}
add_filter( 'the_title', 'dsr_remove_page_title', 10, 2 );

// ==========================================================================
// BREADCRUMBS
// ==========================================================================

/**
 * Output breadcrumb navigation.
 * Compatible with Yoast SEO and Rank Math breadcrumbs.
 */
function dsr_breadcrumbs() {
	// Yoast SEO.
	if ( function_exists( 'yoast_breadcrumb' ) ) {
		yoast_breadcrumb( '<nav class="dsr-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', DSR_TEXT ) . '">', '</nav>' );
		return;
	}

	// Rank Math.
	if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
		echo '<nav class="dsr-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', DSR_TEXT ) . '">';
		rank_math_the_breadcrumbs();
		echo '</nav>';
		return;
	}

	// Custom fallback.
	global $post;
	$home_url   = home_url( '/' );
	$home_label = esc_html__( 'Home', DSR_TEXT );

	echo '<nav class="dsr-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', DSR_TEXT ) . '">';
	echo '<ol class="breadcrumb-list" itemscope itemtype="https://schema.org/BreadcrumbList">';

	// Home.
	echo '<li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
	echo '<a href="' . esc_url( $home_url ) . '" itemprop="item"><span itemprop="name">' . esc_html( $home_label ) . '</span></a>';
	echo '<meta itemprop="position" content="1" />';
	echo '</li>';

	$position = 2;

	if ( is_post_type_archive( 'product' ) ) {
		echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html__( 'Products', DSR_TEXT ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	} elseif ( is_singular( 'product' ) ) {
		echo '<li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<a href="' . esc_url( get_post_type_archive_link( 'product' ) ) . '" itemprop="item"><span itemprop="name">' . esc_html__( 'Products', DSR_TEXT ) . '</span></a>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
		$position++;
		echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html( get_the_title() ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	} elseif ( is_category() || is_single() ) {
		$cats = get_the_category();
		if ( ! empty( $cats ) ) {
			$cat = $cats[0];
			echo '<li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
			echo '<a href="' . esc_url( get_category_link( $cat->term_id ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $cat->name ) . '</span></a>';
			echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
			echo '</li>';
			$position++;
		}
	}

	if ( ! is_post_type_archive( 'product' ) && ! is_singular( 'product' ) ) {
		if ( is_singular() ) {
			echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
			echo '<span itemprop="name">' . esc_html( get_the_title() ) . '</span>';
			echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
			echo '</li>';
		} elseif ( is_category() ) {
			echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page">';
			echo '<span>' . esc_html( single_cat_title( '', false ) ) . '</span>';
			echo '</li>';
		} elseif ( is_search() ) {
			echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page">';
			echo '<span>' . esc_html__( 'Search Results', DSR_TEXT ) . '</span>';
			echo '</li>';
		} elseif ( is_404() ) {
			echo '<li class="breadcrumb-item breadcrumb-current" aria-current="page">';
			echo '<span>' . esc_html__( '404 Not Found', DSR_TEXT ) . '</span>';
			echo '</li>';
		}
	}

	echo '</ol>';
	echo '</nav>';
}

// ==========================================================================
// SOCIAL SHARE BUTTONS
// ==========================================================================

/**
 * Output social share buttons for current post.
 */
function dsr_social_share() {
	if ( ! is_singular() ) {
		return;
	}

	$post_url   = rawurlencode( get_permalink() );
	$post_title = rawurlencode( get_the_title() );
	$post_image = '';
	if ( has_post_thumbnail() ) {
		$img_src    = wp_get_attachment_image_src( get_post_thumbnail_id(), 'dsr-feature' );
		$post_image = ! empty( $img_src[0] ) ? rawurlencode( $img_src[0] ) : '';
	}

	$share_links = array(
		'pinterest' => array(
			'label' => esc_html__( 'Pin on Pinterest', DSR_TEXT ),
			'url'   => 'https://pinterest.com/pin/create/button/?url=' . $post_url . '&media=' . $post_image . '&description=' . $post_title,
			'icon'  => '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/></svg>',
		),
		'facebook'  => array(
			'label' => esc_html__( 'Share on Facebook', DSR_TEXT ),
			'url'   => 'https://www.facebook.com/sharer/sharer.php?u=' . $post_url,
			'icon'  => '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
		),
		'x'         => array(
			'label' => esc_html__( 'Share on X', DSR_TEXT ),
			'url'   => 'https://x.com/intent/tweet?url=' . $post_url . '&text=' . $post_title,
			'icon'  => '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.74l7.73-8.835L1.254 2.25H8.08l4.258 5.629L18.244 2.25zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
		),
		'email'     => array(
			'label' => esc_html__( 'Share via Email', DSR_TEXT ),
			'url'   => 'mailto:?subject=' . $post_title . '&body=' . $post_url,
			'icon'  => '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>',
		),
	);

	echo '<div class="dsr-share-bar" role="group" aria-label="' . esc_attr__( 'Share this recipe', DSR_TEXT ) . '">';
	echo '<span class="share-label">' . esc_html__( 'Share:', DSR_TEXT ) . '</span>';
	echo '<div class="share-buttons">';

	foreach ( $share_links as $network => $data ) {
		printf(
			'<a href="%1$s" class="share-btn share-btn--%2$s" target="_blank" rel="noopener noreferrer" aria-label="%3$s">%4$s <span class="share-btn-label">%5$s</span></a>',
			esc_url( $data['url'] ),
			esc_attr( $network ),
			esc_attr( $data['label'] ),
			wp_kses_post( $data['icon'] ),
			esc_html( ucfirst( $network === 'x' ? 'X' : $network ) )
		);
	}

	// Copy link button.
	printf(
		'<button type="button" class="share-btn share-btn--copy" aria-label="%s" data-url="%s">
			<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
			<span class="share-btn-label">%s</span>
		</button>',
		esc_attr__( 'Copy link', DSR_TEXT ),
		esc_url( get_permalink() ),
		esc_html__( 'Copy', DSR_TEXT )
	);

	echo '</div>';
	echo '</div>';
}

// ==========================================================================
// RELATED RECIPES
// ==========================================================================

/**
 * Output related recipes (by category, then by tag).
 *
 * @param int $count Number of related posts to show. Default 4.
 */
function dsr_related_recipes( $count = 4 ) {
	global $post;
	if ( ! $post ) {
		return;
	}

	$cats = wp_get_post_categories( $post->ID, array( 'fields' => 'ids' ) );
	$tags = wp_get_post_tags( $post->ID, array( 'fields' => 'ids' ) );

	$query_args = array(
		'post_type'           => array( 'post', 'recipe' ),
		'posts_per_page'      => absint( $count ),
		'post__not_in'        => array( $post->ID ),
		'ignore_sticky_posts' => true,
		'orderby'             => 'rand',
		'no_found_rows'       => true,
	);

	if ( ! empty( $cats ) ) {
		$query_args['category__in'] = $cats;
	} elseif ( ! empty( $tags ) ) {
		$query_args['tag__in'] = $tags;
	}

	$related = new WP_Query( $query_args );

	if ( ! $related->have_posts() ) {
		// Fallback: latest posts.
		$query_args = array(
			'post_type'           => array( 'post', 'recipe' ),
			'posts_per_page'      => absint( $count ),
			'post__not_in'        => array( $post->ID ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		$related    = new WP_Query( $query_args );
	}

	if ( $related->have_posts() ) :
		?>
		<section class="dsr-related-recipes" aria-label="<?php esc_attr_e( 'More Recipes', DSR_TEXT ); ?>">
			<div class="container">
				<div class="section-header">
					<h2 class="section-title"><?php esc_html_e( "More Recipes You'll Love", DSR_TEXT ); ?></h2>
				</div>
				<div class="recipe-grid recipe-grid--4">
					<?php
					while ( $related->have_posts() ) :
						$related->the_post();
						get_template_part( 'template-parts/content/content', 'recipe' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
		<?php
	endif;
}

/**
 * Output related products (by product_category, then fallback to recent products).
 *
 * @param int $count Number of related products to show. Default 4.
 */
function dsr_related_products( $count = 4 ) {
	global $post;
	if ( ! $post ) {
		return;
	}

	$terms    = get_the_terms( $post->ID, 'product_category' );
	$term_ids = array();
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		$term_ids = wp_list_pluck( $terms, 'term_id' );
	}

	$query_args = array(
		'post_type'           => 'product',
		'posts_per_page'      => absint( $count ),
		'post__not_in'        => array( $post->ID ),
		'ignore_sticky_posts' => true,
		'orderby'             => 'rand',
		'no_found_rows'       => true,
	);

	if ( ! empty( $term_ids ) ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => 'product_category',
				'field'    => 'term_id',
				'terms'    => $term_ids,
			),
		);
	}

	$related = new WP_Query( $query_args );

	if ( ! $related->have_posts() ) {
		$query_args = array(
			'post_type'           => 'product',
			'posts_per_page'      => absint( $count ),
			'post__not_in'        => array( $post->ID ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		$related    = new WP_Query( $query_args );
	}

	if ( $related->have_posts() ) :
		?>
		<section class="dsr-related-products" aria-label="<?php esc_attr_e( 'More Products', DSR_TEXT ); ?>" style="padding: var(--space-12) 0; background: var(--color-surface, #ffffff);">
			<div class="container">
				<div class="section-header" style="text-align:center; margin-bottom: var(--space-8);">
					<h2 class="section-title"><?php esc_html_e( 'More Products & Guides', DSR_TEXT ); ?></h2>
				</div>
				<div class="dsr-products-grid">
					<?php
					while ( $related->have_posts() ) :
						$related->the_post();
						get_template_part( 'template-parts/product/content', 'product' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
		<?php
	endif;
}

// ==========================================================================
// RECIPE META
// ==========================================================================

/**
 * Output recipe meta info (author, date, category).
 */
function dsr_recipe_meta() {
	$cats = get_the_category();
	?>
	<div class="dsr-post-meta">
		<?php if ( ! empty( $cats ) ) : ?>
			<a href="<?php echo esc_url( get_category_link( $cats[0]->term_id ) ); ?>" class="post-meta-category">
				<?php echo esc_html( $cats[0]->name ); ?>
			</a>
		<?php endif; ?>
		<span class="post-meta-author">
			<?php
			printf(
				/* translators: %s: Author name */
				esc_html__( 'By %s', DSR_TEXT ),
				'<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>'
			);
			?>
		</span>
		<time class="post-meta-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
			<?php echo esc_html( get_the_date() ); ?>
		</time>
		<?php
		// Show "Updated" date if it differs significantly from publish date.
		$published  = get_the_date( 'U' );
		$modified   = get_the_modified_date( 'U' );
		if ( $modified && ( $modified - $published ) > 86400 * 7 ) :
			?>
			<span class="post-meta-updated">
				<?php
				printf(
					/* translators: %s: Updated date */
					esc_html__( 'Updated: %s', DSR_TEXT ),
					'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>'
				);
				?>
			</span>
		<?php endif; ?>
	</div>
	<?php
}

// ==========================================================================
// POST THUMBNAIL WITH FALLBACK
// ==========================================================================

/**
 * Output post thumbnail with a fallback SVG if no image.
 *
 * @param string $size Image size slug.
 * @param array  $attrs Extra attributes.
 */
function dsr_post_thumbnail( $size = 'dsr-card', $attrs = array() ) {
	if ( has_post_thumbnail() ) {
		the_post_thumbnail( $size, $attrs );
	} else {
		$unsplash_salads = array(
			'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
			'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80',
			'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
			'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?auto=format&fit=crop&w=800&q=80',
			'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=800&q=80',
			'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=800&q=80',
		);
		$post_id = get_the_ID();
		$img_url = $unsplash_salads[ ( $post_id ? $post_id : 0 ) % count( $unsplash_salads ) ];
		$alt_text = esc_attr( get_the_title() ? get_the_title() : __( 'Salad Recipe', DSR_TEXT ) );
		echo '<img src="' . esc_url( $img_url ) . '" alt="' . $alt_text . '" class="dsr-placeholder-img" loading="lazy" />';
	}
}

// ==========================================================================
// PAGINATION
// ==========================================================================

/**
 * Output posts pagination.
 */
function dsr_posts_pagination() {
	the_posts_pagination(
		array(
			'mid_size'           => 2,
			'prev_text'          => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6z"/></svg><span class="sr-only">' . esc_html__( 'Previous page', DSR_TEXT ) . '</span>',
			'next_text'          => '<span class="sr-only">' . esc_html__( 'Next page', DSR_TEXT ) . '</span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>',
			'before_page_number' => '<span class="meta-nav sr-only">' . esc_html__( 'Page', DSR_TEXT ) . ' </span>',
			'screen_reader_text' => esc_html__( 'Posts navigation', DSR_TEXT ),
		)
	);
}

// ==========================================================================
// READING TIME
// ==========================================================================

/**
 * Estimate post reading time.
 *
 * @return int Minutes to read.
 */
function dsr_reading_time() {
	$content    = get_post_field( 'post_content', get_the_ID() );
	$word_count = str_word_count( wp_strip_all_tags( $content ) );
	$minutes    = max( 1, (int) ceil( $word_count / 200 ) );
	return $minutes;
}

// ==========================================================================
// LOGO
// ==========================================================================

/**
 * Output theme logo or site title.
 */
function dsr_logo() {
	if ( has_custom_logo() ) {
		the_custom_logo();
	} else {
		?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title-link" rel="home">
			<span class="site-title-text"><?php bloginfo( 'name' ); ?></span>
		</a>
		<?php
	}
}

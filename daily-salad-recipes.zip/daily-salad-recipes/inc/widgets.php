<?php
/**
 * Daily Salad Recipes — Widget Areas
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function dsr_widgets_init() {

	// Recipe/Post sidebar.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Recipe Sidebar', DSR_TEXT ),
			'id'            => 'sidebar-recipe',
			'description'   => esc_html__( 'Appears on the right side of individual posts and recipes.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	// Footer column 1.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Column 1', DSR_TEXT ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'First column of the footer widget area.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);

	// Footer column 2.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Column 2', DSR_TEXT ),
			'id'            => 'footer-2',
			'description'   => esc_html__( 'Second column of the footer widget area.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);

	// Newsletter widget area.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Newsletter Form', DSR_TEXT ),
			'id'            => 'newsletter-form',
			'description'   => esc_html__( 'Insert your newsletter plugin form here (Mailchimp, MailPoet, FluentCRM, etc).', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="newsletter-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<span class="sr-only">',
			'after_title'   => '</span>',
		)
	);

	// Ad slot — header.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Ad: Header', DSR_TEXT ),
			'id'            => 'ad-header',
			'description'   => esc_html__( 'Advertisement slot below the site header.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="ad-widget ad-header-slot %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<span class="sr-only">',
			'after_title'   => '</span>',
		)
	);

	// Ad slot — after recipe card.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Ad: After Recipe Card', DSR_TEXT ),
			'id'            => 'ad-after-recipe',
			'description'   => esc_html__( 'Advertisement slot displayed after the recipe card.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="ad-widget ad-after-recipe %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<span class="sr-only">',
			'after_title'   => '</span>',
		)
	);

	// Ad slot — sidebar.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Ad: Sidebar', DSR_TEXT ),
			'id'            => 'ad-sidebar',
			'description'   => esc_html__( 'Advertisement slot in the sidebar.', DSR_TEXT ),
			'before_widget' => '<div id="%1$s" class="ad-widget ad-sidebar-slot %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<span class="sr-only">',
			'after_title'   => '</span>',
		)
	);
}
add_action( 'widgets_init', 'dsr_widgets_init' );

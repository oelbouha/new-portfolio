<?php
/**
 * Daily Salad Recipes — Fallback Index Template
 *
 * WordPress falls back to this if no more specific template exists.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<div style="padding:var(--space-12) 0 var(--space-20);background:var(--color-bg);">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<div class="recipe-grid recipe-grid--4">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', 'recipe' );
					endwhile;
					?>
				</div>

				<?php dsr_posts_pagination(); ?>

			<?php else : ?>
				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
			<?php endif; ?>

		</div>
	</div>

</main>

<?php get_footer(); ?>

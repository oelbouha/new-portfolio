<?php
/**
 * Template Name: About Page
 * Description: Premium custom About Us page for Daily Salad Recipes.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Customizer Options
$hero_eyebrow   = get_theme_mod( 'dsr_about_hero_eyebrow', esc_html__( 'Our Mission & Story', DSR_TEXT ) );
$hero_title     = get_theme_mod( 'dsr_about_hero_title', esc_html__( 'Vibrant, Delicious & Wholesome Salads Every Single Day', DSR_TEXT ) );
$hero_subtitle  = get_theme_mod( 'dsr_about_hero_subtitle', esc_html__( 'We are dedicated to proving that healthy eating should never be boring, repetitive, or complicated.', DSR_TEXT ) );

$story_img      = get_theme_mod( 'dsr_about_story_image', 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1000&q=80' );
$story_heading  = get_theme_mod( 'dsr_about_story_heading', esc_html__( 'Welcome to Daily Salad Recipes', DSR_TEXT ) );
$story_lead     = get_theme_mod( 'dsr_about_story_lead', esc_html__( 'What started as a small personal obsession with fresh produce has grown into a vibrant publication dedicated to salad lovers worldwide.', DSR_TEXT ) );
$story_p1       = get_theme_mod( 'dsr_about_story_p1', esc_html__( 'At Daily Salad Recipes, we believe a great salad is an art form — combining textures, colors, homemade dressings, and nutritionally dense ingredients to create meals you genuinely crave.', DSR_TEXT ) );
$story_p2       = get_theme_mod( 'dsr_about_story_p2', esc_html__( 'Whether you are looking for quick 15-minute weekday lunch bowls, high-protein post-workout options, crunchy Mediterranean dishes, or decadent dinner salads for entertaining guests, we have got you covered.', DSR_TEXT ) );

$values_eyebrow = get_theme_mod( 'dsr_about_values_eyebrow', esc_html__( 'What Drives Us', DSR_TEXT ) );
$values_title   = get_theme_mod( 'dsr_about_values_title', esc_html__( 'Our Culinary Promises', DSR_TEXT ) );

$val1_icon  = get_theme_mod( 'dsr_about_val1_icon', '🥗' );
$val1_title = get_theme_mod( 'dsr_about_val1_title', esc_html__( 'Flavor First', DSR_TEXT ) );
$val1_desc  = get_theme_mod( 'dsr_about_val1_desc', esc_html__( 'No bland greens here. Every recipe balances crunch, zesty dressings, quality proteins, and bold seasonings.', DSR_TEXT ) );

$val2_icon  = get_theme_mod( 'dsr_about_val2_icon', '🥑' );
$val2_title = get_theme_mod( 'dsr_about_val2_title', esc_html__( 'Nutrient Dense', DSR_TEXT ) );
$val2_desc  = get_theme_mod( 'dsr_about_val2_desc', esc_html__( 'Our recipes prioritize whole-food ingredients packed with vitamins, healthy fats, fiber, and clean energy.', DSR_TEXT ) );

$val3_icon  = get_theme_mod( 'dsr_about_val3_icon', '⏱' );
$val3_title = get_theme_mod( 'dsr_about_val3_title', esc_html__( 'Easy Preparation', DSR_TEXT ) );
$val3_desc  = get_theme_mod( 'dsr_about_val3_desc', esc_html__( 'Clear instructions, simple prep times, and accessible supermarket ingredients for busy everyday cooks.', DSR_TEXT ) );
?>

<main id="main" role="main" class="dsr-about-page">

	<!-- About Hero -->
	<header class="dsr-page-hero">
		<div class="container">
			<?php if ( $hero_eyebrow ) : ?>
				<span class="section-eyebrow" data-customizer="dsr_about_hero_eyebrow"><?php echo esc_html( $hero_eyebrow ); ?></span>
			<?php endif; ?>
			<?php if ( $hero_title ) : ?>
				<h1 class="page-hero__title" data-customizer="dsr_about_hero_title"><?php echo esc_html( $hero_title ); ?></h1>
			<?php endif; ?>
			<?php if ( $hero_subtitle ) : ?>
				<p class="page-hero__subtitle" data-customizer="dsr_about_hero_subtitle"><?php echo esc_html( $hero_subtitle ); ?></p>
			<?php endif; ?>
		</div>
	</header>

	<!-- Main Story Section -->
	<section class="dsr-about-story">
		<div class="container">
			<div class="about-story-grid">
				<div class="about-story__image-wrap">
					<img src="<?php echo esc_url( $story_img ); ?>" alt="<?php echo esc_attr( $story_heading ); ?>" loading="eager" />
				</div>
				<div class="about-story__content">
					<?php if ( $story_heading ) : ?>
						<h2 class="about-story__heading" data-customizer="dsr_about_story_heading"><?php echo esc_html( $story_heading ); ?></h2>
					<?php endif; ?>
					<?php if ( $story_lead ) : ?>
						<p class="about-story__lead" data-customizer="dsr_about_story_lead"><?php echo esc_html( $story_lead ); ?></p>
					<?php endif; ?>
					<?php if ( $story_p1 ) : ?>
						<p data-customizer="dsr_about_story_p1"><?php echo esc_html( $story_p1 ); ?></p>
					<?php endif; ?>
					<?php if ( $story_p2 ) : ?>
						<p data-customizer="dsr_about_story_p2"><?php echo esc_html( $story_p2 ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<!-- Core Culinary Pillars -->
	<section class="dsr-about-values">
		<div class="container">
			<div class="section-header">
				<?php if ( $values_eyebrow ) : ?>
					<span class="section-eyebrow" data-customizer="dsr_about_values_eyebrow"><?php echo esc_html( $values_eyebrow ); ?></span>
				<?php endif; ?>
				<?php if ( $values_title ) : ?>
					<h2 class="section-title" data-customizer="dsr_about_values_title"><?php echo esc_html( $values_title ); ?></h2>
				<?php endif; ?>
			</div>

			<div class="values-grid">
				<div class="value-card">
					<div class="value-card__icon" data-customizer="dsr_about_val1_icon"><?php echo esc_html( $val1_icon ); ?></div>
					<h3 data-customizer="dsr_about_val1_title"><?php echo esc_html( $val1_title ); ?></h3>
					<p data-customizer="dsr_about_val1_desc"><?php echo esc_html( $val1_desc ); ?></p>
				</div>
				<div class="value-card">
					<div class="value-card__icon" data-customizer="dsr_about_val2_icon"><?php echo esc_html( $val2_icon ); ?></div>
					<h3 data-customizer="dsr_about_val2_title"><?php echo esc_html( $val2_title ); ?></h3>
					<p data-customizer="dsr_about_val2_desc"><?php echo esc_html( $val2_desc ); ?></p>
				</div>
				<div class="value-card">
					<div class="value-card__icon" data-customizer="dsr_about_val3_icon"><?php echo esc_html( $val3_icon ); ?></div>
					<h3 data-customizer="dsr_about_val3_title"><?php echo esc_html( $val3_title ); ?></h3>
					<p data-customizer="dsr_about_val3_desc"><?php echo esc_html( $val3_desc ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- Photo Gallery Grid -->
	<section class="dsr-about-gallery">
		<div class="container">
			<div class="gallery-grid">
				<div class="gallery-item"><img src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80" alt="Salad 1" loading="lazy" /></div>
				<div class="gallery-item"><img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80" alt="Salad 2" loading="lazy" /></div>
				<div class="gallery-item"><img src="https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?auto=format&fit=crop&w=600&q=80" alt="Salad 3" loading="lazy" /></div>
				<div class="gallery-item"><img src="https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=600&q=80" alt="Salad 4" loading="lazy" /></div>
			</div>
		</div>
	</section>

	<!-- Page Content (Gutenberg block compatibility) -->
	<?php if ( get_the_content() ) : ?>
		<div class="container">
			<div class="entry-content" style="padding:var(--space-12) 0;">
				<?php the_content(); ?>
			</div>
		</div>
	<?php endif; ?>

</main>

<?php get_footer(); ?>

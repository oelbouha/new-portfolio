<?php
/**
 * Daily Salad Recipes — Static Page Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<div style="padding:var(--space-12) 0 var(--space-20);background:var(--color-bg);">
		<div class="container">

			<?php while ( have_posts() ) : the_post(); ?>

				<article <?php post_class( 'dsr-page-content' ); ?> id="post-<?php the_ID(); ?>">

					<header class="dsr-post-header" style="margin-bottom:var(--space-8);">
						<?php dsr_breadcrumbs(); ?>
					</header>

					<?php if ( has_post_thumbnail() ) : ?>
						<div class="dsr-post-hero-image">
							<?php the_post_thumbnail( 'dsr-wide', array( 'loading' => 'eager', 'alt' => esc_attr( get_the_title() ) ) ); ?>
						</div>
					<?php endif; ?>

					<div class="entry-content">
						<?php the_content(); ?>
					</div>

					<?php
					wp_link_pages(
						array(
							'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Page', DSR_TEXT ) . '"><span class="page-links-title">' . esc_html__( 'Pages:', DSR_TEXT ) . '</span>',
							'after'  => '</nav>',
						)
					);
					?>

				</article>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>

			<?php endwhile; ?>

		</div>
	</div>

</main>

<?php get_footer(); ?>

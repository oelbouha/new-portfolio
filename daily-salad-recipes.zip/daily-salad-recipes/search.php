<?php
/**
 * Daily Salad Recipes — Search Results Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main" class="dsr-search-page">

	<!-- Search Header -->
	<header class="dsr-search-header">
		<div class="container">
			<h1 class="search-header__title">
				<?php
				if ( get_search_query() ) {
					printf(
						/* translators: %s: search query */
						esc_html__( 'Search Results for "%s"', DSR_TEXT ),
						'<span>' . esc_html( get_search_query() ) . '</span>'
					);
				} else {
					esc_html_e( 'Search Salad Recipes', DSR_TEXT );
				}
				?>
			</h1>

			<div class="dsr-search-form-wrap">
				<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" class="dsr-clean-search-form">
					<label for="search-input-page" class="sr-only"><?php esc_html_e( 'Search recipes', DSR_TEXT ); ?></label>
					<input
						type="search"
						id="search-input-page"
						name="s"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search by ingredient or recipe name...', DSR_TEXT ); ?>"
						autocomplete="off"
						required
					/>
					<button type="submit" class="btn btn--primary">
						<?php esc_html_e( 'Search', DSR_TEXT ); ?>
					</button>
				</form>
			</div>
		</div>
	</header>

	<!-- Results Section -->
	<section class="dsr-search-body">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<div class="search-results-meta">
					<?php
					printf(
						/* translators: 1: number of results, 2: search query */
						esc_html__( 'Found %1$s recipe results for "%2$s"', DSR_TEXT ),
						'<span class="search-count-badge">' . absint( $wp_query->found_posts ) . '</span>',
						'<strong>' . esc_html( get_search_query() ) . '</strong>'
					);
					?>
				</div>

				<div class="recipe-grid recipe-grid--3">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', 'search' );
					endwhile;
					?>
				</div>

				<?php dsr_posts_pagination(); ?>

			<?php else : ?>

				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>

			<?php endif; ?>

		</div>
	</section>

</main>

<?php get_footer(); ?>

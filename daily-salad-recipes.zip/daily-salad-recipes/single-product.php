<?php
/**
 * Daily Salad Recipes — Single Product Template
 *
 * Displays individual digital product pages with a layout inspired
 * by the blog post page (single.php): header, hero image, share bar,
 * full content, related products, and newsletter CTA.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$price        = dsr_get_product_price();
$purchase_url = dsr_get_product_purchase_url();
$short_desc   = dsr_get_product_short_desc();
$badge        = dsr_get_product_badge();
$terms        = get_the_terms( get_the_ID(), 'product_category' );
$cat_name     = ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
$cat_link     = ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? get_term_link( $terms[0] ) : '';

// SEO: Product JSON-LD schema.
add_action( 'wp_head', function() use ( $price, $purchase_url, $short_desc ) {
	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Product',
		'name'        => get_the_title(),
		'description' => $short_desc ? $short_desc : wp_trim_words( get_the_content(), 30, '...' ),
		'url'         => get_permalink(),
	);

	if ( has_post_thumbnail() ) {
		$img_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'dsr-hero' );
		if ( ! empty( $img_src[0] ) ) {
			$schema['image'] = $img_src[0];
		}
	}

	if ( $price ) {
		// Extract numeric value from price string.
		$numeric = preg_replace( '/[^0-9.]/', '', $price );
		if ( $numeric ) {
			$schema['offers'] = array(
				'@type'         => 'Offer',
				'price'         => $numeric,
				'priceCurrency' => 'USD',
				'url'           => $purchase_url ? $purchase_url : get_permalink(),
				'availability'  => 'https://schema.org/InStock',
			);
		}
	}

	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 5 );

// SEO: Meta tags.
add_action( 'wp_head', function() use ( $short_desc ) {
	$desc = $short_desc ? $short_desc : wp_trim_words( get_the_excerpt(), 25, '...' );
	echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( get_the_title() ) . '" />' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
	echo '<meta property="og:type" content="product" />' . "\n";
	echo '<meta property="og:url" content="' . esc_url( get_permalink() ) . '" />' . "\n";
	if ( has_post_thumbnail() ) {
		$img = wp_get_attachment_image_src( get_post_thumbnail_id(), 'dsr-hero' );
		if ( ! empty( $img[0] ) ) {
			echo '<meta property="og:image" content="' . esc_url( $img[0] ) . '" />' . "\n";
		}
	}
}, 1 );

get_header();
?>

<main id="main" role="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<!-- Reading progress bar -->
		<div class="reading-progress-bar" aria-hidden="true" style="position:fixed;top:var(--header-height);left:0;height:3px;background:var(--color-accent);z-index:999;width:0;transition:width 0.1s linear;"></div>

		<div class="dsr-single dsr-single-product">
			<div class="container">

				<!-- Breadcrumbs -->
				<?php dsr_breadcrumbs(); ?>

				<div class="dsr-single-layout">

					<!-- Main Content Column -->
					<div class="dsr-single-content">

						<!-- Product Header -->
						<header class="dsr-post-header">
							<?php if ( $cat_name ) : ?>
								<a href="<?php echo esc_url( $cat_link ); ?>" class="post-category">
									<?php echo esc_html( $cat_name ); ?>
								</a>
							<?php endif; ?>

							<h1 class="post-title"><?php the_title(); ?></h1>

							<?php if ( $short_desc ) : ?>
								<p class="post-description"><?php echo esc_html( $short_desc ); ?></p>
							<?php endif; ?>

							<!-- Product Meta (Price + Author + Date) -->
							<div class="dsr-post-meta">
								<?php if ( $price ) : ?>
									<span class="post-meta-category dsr-product-price-badge"><?php echo esc_html( $price ); ?></span>
								<?php endif; ?>
								<span class="post-meta-author">
									<?php
									printf(
										/* translators: %s: Author name */
										esc_html__( 'By %s', DSR_TEXT ),
										'<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>'
									);
									?>
								</span>
								<time class="post-meta-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
									<?php echo esc_html( get_the_date() ); ?>
								</time>
							</div>
						</header>

						<!-- Product Full Image with Lightbox Zoom -->
						<?php
						$full_img_url = '';
						if ( has_post_thumbnail() ) {
							$img_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
							if ( $img_src ) {
								$full_img_url = $img_src[0];
							}
						}
						if ( ! $full_img_url ) {
							$full_img_url = 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1600&q=80';
						}
						?>
						<div class="dsr-product-hero-image-wrap">
							<?php if ( $badge ) : ?>
								<span class="dsr-product-card__badge" style="position:absolute;top:var(--space-4);left:var(--space-4);z-index:2;"><?php echo esc_html( $badge ); ?></span>
							<?php endif; ?>

							<a href="<?php echo esc_url( $full_img_url ); ?>" class="dsr-product-image-lightbox" data-lightbox="product" data-title="<?php echo esc_attr( get_the_title() ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'View image of %s', DSR_TEXT ), get_the_title() ) ); ?>">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'full', array( 'loading' => 'eager', 'alt' => esc_attr( get_the_title() ), 'class' => 'dsr-product-full-img' ) ); ?>
								<?php else : ?>
									<img src="<?php echo esc_url( $full_img_url ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="eager" class="dsr-product-full-img" />
								<?php endif; ?>
							</a>
						</div>

						<!-- Purchase Action Bar -->
						<div class="dsr-recipe-action-bar">
							<a href="<?php echo esc_url( $purchase_url ); ?>" class="btn btn--accent btn--sm" target="_blank" rel="noopener noreferrer">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
								<?php esc_html_e( 'Buy Now', DSR_TEXT ); ?>
								<?php if ( $price ) : ?>
									— <?php echo esc_html( $price ); ?>
								<?php endif; ?>
							</a>
						</div>

						<!-- Social Share -->
						<?php dsr_social_share(); ?>

						<!-- Product Content -->
						<div class="entry-content">
							<?php the_content(); ?>
						</div>

						<!-- Purchase CTA Box (after content) -->
						<div class="dsr-product-bottom-cta">
							<div class="dsr-product-bottom-cta__inner">
								<div class="dsr-product-bottom-cta__info">
									<h3><?php the_title(); ?></h3>
									<?php if ( $price ) : ?>
										<span class="dsr-product-bottom-cta__price"><?php echo esc_html( $price ); ?></span>
									<?php endif; ?>
								</div>
								<a href="<?php echo esc_url( $purchase_url ); ?>" class="btn btn--accent" target="_blank" rel="noopener noreferrer">
									<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
									<?php esc_html_e( 'Buy Product Now', DSR_TEXT ); ?>
								</a>
							</div>
							<div class="dsr-product-bottom-cta__trust">
								<span>✓ <?php esc_html_e( 'Instant Digital Download', DSR_TEXT ); ?></span>
								<span>✓ <?php esc_html_e( 'Mobile & Print Friendly', DSR_TEXT ); ?></span>
								<span>✓ <?php esc_html_e( 'Lifetime Access', DSR_TEXT ); ?></span>
							</div>
						</div>

					</div><!-- /.dsr-single-content -->

					<!-- Sidebar -->
					<aside class="dsr-sidebar" aria-label="<?php esc_attr_e( 'Sidebar', DSR_TEXT ); ?>">
						<?php get_sidebar(); ?>
					</aside>

				</div><!-- /.dsr-single-layout -->

			</div><!-- /.container -->
		</div><!-- /.dsr-single -->

		<!-- Related Products -->
		<?php dsr_related_products( 4 ); ?>

		<!-- Newsletter CTA -->
		<?php get_template_part( 'template-parts/home/newsletter' ); ?>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>

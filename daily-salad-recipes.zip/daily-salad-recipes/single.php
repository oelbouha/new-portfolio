<?php
/**
 * Daily Salad Recipes — Single Post / Recipe Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="main" role="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<!-- Reading progress bar -->
		<div class="reading-progress-bar" aria-hidden="true" style="position:fixed;top:var(--header-height);left:0;height:3px;background:var(--color-accent);z-index:999;width:0;transition:width 0.1s linear;"></div>

		<div class="dsr-single">
			<div class="container">

				<!-- Breadcrumbs -->
				<?php dsr_breadcrumbs(); ?>

				<div class="dsr-single-layout">

					<!-- Main Content -->
					<div class="dsr-single-content">

						<!-- Post Header -->
						<header class="dsr-post-header">
							<?php
							$cats = get_the_category();
							if ( ! empty( $cats ) ) :
								?>
								<a href="<?php echo esc_url( get_category_link( $cats[0]->term_id ) ); ?>" class="post-category">
									<?php echo esc_html( $cats[0]->name ); ?>
								</a>
							<?php endif; ?>

							<h1 class="post-title"><?php the_title(); ?></h1>

							<?php if ( get_the_excerpt() ) : ?>
								<p class="post-description"><?php the_excerpt(); ?></p>
							<?php endif; ?>

							<?php dsr_recipe_meta(); ?>
						</header>

						<!-- Hero Image -->
						<div class="dsr-recipe-hero-image">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'dsr-hero', array( 'loading' => 'eager', 'alt' => esc_attr( get_the_title() ) ) ); ?>
							<?php else : ?>
								<img src="https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1200&q=80" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="eager" style="width:100%;height:auto;max-height:550px;object-fit:cover;border-radius:var(--radius-lg);" />
							<?php endif; ?>
						</div>

						<!-- Jump to Recipe / Action Bar -->
						<div class="dsr-recipe-action-bar">
							<button type="button" class="btn btn--primary btn--sm dsr-jump-to-recipe">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
								<?php esc_html_e( 'Jump to Recipe', DSR_TEXT ); ?>
							</button>
							<button type="button" class="btn btn--secondary btn--sm" onclick="window.print();">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
								<?php esc_html_e( 'Print', DSR_TEXT ); ?>
							</button>
						</div>

						<!-- Social Share -->
						<?php dsr_social_share(); ?>

						<!-- Post Content (intro text + WP Delicious recipe card) -->
						<div class="entry-content" id="recipe-card-target">
							<?php the_content(); ?>
						</div>

						<!-- After-recipe ad slot -->
						<?php if ( is_active_sidebar( 'ad-after-recipe' ) ) : ?>
							<div class="ad-widget-wrap" aria-label="<?php esc_attr_e( 'Advertisement', DSR_TEXT ); ?>">
								<?php dynamic_sidebar( 'ad-after-recipe' ); ?>
							</div>
						<?php endif; ?>


					</div><!-- /.dsr-single-content -->

					<!-- Sidebar -->
					<aside class="dsr-sidebar" aria-label="<?php esc_attr_e( 'Sidebar', DSR_TEXT ); ?>">
						<?php get_sidebar(); ?>
					</aside>

				</div><!-- /.dsr-single-layout -->

			</div><!-- /.container -->
		</div><!-- /.dsr-single -->

		<!-- Related Recipes -->
		<?php dsr_related_recipes( 4 ); ?>

		<!-- Newsletter CTA -->
		<?php get_template_part( 'template-parts/home/newsletter' ); ?>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>

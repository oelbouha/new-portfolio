<?php
/**
 * Daily Salad Recipes — No Results / Content None Template
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="no-results not-found" aria-label="<?php esc_attr_e( 'No results found', DSR_TEXT ); ?>">
	<div class="dsr-no-results-card">
		<div class="dsr-no-results-icon" aria-hidden="true">🥗</div>
		<h2 class="dsr-no-results-title">
			<?php esc_html_e( 'No Recipes Found', DSR_TEXT ); ?>
		</h2>
		<p class="dsr-no-results-text">
			<?php
			if ( is_search() ) {
				printf(
					/* translators: %s: search query */
					esc_html__( 'We couldn\'t find any recipes matching "%s". Try searching for ingredients like "avocado", "quinoa", or "spinach".', DSR_TEXT ),
					'<strong>' . esc_html( get_search_query() ) . '</strong>'
				);
			} else {
				esc_html_e( 'It seems we can\'t find what you\'re looking for. Try browsing our recommended salad recipes below.', DSR_TEXT );
			}
			?>
		</p>

		<div class="dsr-no-results-search-wrap">
			<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" class="dsr-clean-search-form">
				<label for="no-results-search-input" class="sr-only"><?php esc_html_e( 'Search recipes', DSR_TEXT ); ?></label>
				<input
					type="search"
					id="no-results-search-input"
					name="s"
					value="<?php echo esc_attr( get_search_query() ); ?>"
					placeholder="<?php esc_attr_e( 'Search recipes...', DSR_TEXT ); ?>"
					required
				/>
				<button type="submit" class="btn btn--primary">
					<?php esc_html_e( 'Search', DSR_TEXT ); ?>
				</button>
			</form>
		</div>
	</div>

	<!-- Recommended Recipes Suggestion Grid -->
	<?php
	$suggest_query = new WP_Query(
		array(
			'post_type'      => array( 'post', 'recipe' ),
			'posts_per_page' => 3,
			'orderby'        => 'rand',
		)
	);

	if ( $suggest_query->have_posts() ) :
		?>
		<div class="dsr-search-suggestions">
			<h3 class="dsr-suggestions-heading">
				<?php esc_html_e( 'Popular Salad Recipes You Might Love', DSR_TEXT ); ?>
			</h3>
			<div class="recipe-grid recipe-grid--3">
				<?php
				while ( $suggest_query->have_posts() ) :
					$suggest_query->the_post();
					get_template_part( 'template-parts/content/content', 'recipe' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
	<?php endif; ?>
</section>

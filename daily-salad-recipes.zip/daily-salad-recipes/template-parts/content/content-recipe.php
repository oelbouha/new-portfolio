<?php
/**
 * Daily Salad Recipes — Recipe Card (for loops/grids)
 *
 * Used in: homepage grids, archive, search, related recipes.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cats = get_the_category();
?>

<article <?php post_class( 'recipe-card' ); ?> id="post-<?php the_ID(); ?>">
	<!-- Image -->
	<a href="<?php the_permalink(); ?>" class="recipe-card__image-wrap" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
		<?php dsr_post_thumbnail( 'dsr-card', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) ); ?>
	</a>

	<div class="recipe-card__body">
		<h3 class="recipe-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>
	</div>
</article>

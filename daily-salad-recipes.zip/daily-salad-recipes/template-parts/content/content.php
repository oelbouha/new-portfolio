<?php
/**
 * Daily Salad Recipes — Generic Post Content
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article <?php post_class( 'dsr-post' ); ?> id="post-<?php the_ID(); ?>">

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="dsr-post-hero-image">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'dsr-feature', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) ); ?>
			</a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
		<?php dsr_recipe_meta(); ?>
	</header>

	<div class="entry-summary">
		<?php the_excerpt(); ?>
		<a href="<?php the_permalink(); ?>" class="btn btn--secondary btn--sm"><?php esc_html_e( 'Read More', DSR_TEXT ); ?></a>
	</div>

</article>

<?php
/**
 * Daily Salad Recipes — Mobile Menu Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mobile-nav-overlay" aria-hidden="true"></div>

<nav class="mobile-nav" id="mobile-nav" aria-label="<?php esc_attr_e( 'Mobile Navigation', DSR_TEXT ); ?>" aria-hidden="true">
	<div class="mobile-nav-header">
		<?php dsr_logo(); ?>
		<button type="button" class="mobile-nav-close" aria-label="<?php esc_attr_e( 'Close menu', DSR_TEXT ); ?>">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
		</button>
	</div>

	<?php if ( has_nav_menu( 'primary' ) ) : ?>
		<div class="mobile-menu">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_class'     => 'menu',
					'container'      => false,
					'depth'          => 2,
					'fallback_cb'    => false,
				)
			);
			?>
		</div>
	<?php endif; ?>
</nav>

<?php
/**
 * Daily Salad Recipes — Main Site Header Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<header id="masthead" class="site-header" role="banner">
	<div class="dsr-container header-inner">
		<div class="site-branding">
			<?php dsr_logo(); ?>
		</div>

		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<nav class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', DSR_TEXT ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_class'     => 'primary-menu',
						'container'      => false,
						'depth'          => 2,
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<div class="header-actions">
			<button type="button" class="header-search-toggle" aria-label="<?php esc_attr_e( 'Open Search', DSR_TEXT ); ?>" aria-controls="search-overlay">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
			</button>

			<button type="button" class="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle Menu', DSR_TEXT ); ?>" aria-controls="mobile-nav">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
			</button>
		</div>
	</div>
</header>

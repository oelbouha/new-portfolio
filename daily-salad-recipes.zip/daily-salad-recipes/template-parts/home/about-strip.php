<?php
/**
 * Daily Salad Recipes — About Strip
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$about_image_id = get_theme_mod( 'dsr_about_image', 0 );
$about_eyebrow  = get_theme_mod( 'dsr_about_eyebrow', esc_html__( 'Our Story', DSR_TEXT ) );
$about_heading  = get_theme_mod( 'dsr_about_heading', esc_html__( 'Welcome to Daily Salad Recipes', DSR_TEXT ) );
$about_text     = get_theme_mod( 'dsr_about_text', esc_html__( 'Daily Salad Recipes is a recipe website dedicated to making fresh, delicious salads easier to prepare at home. Explore simple green salads, vegetable salads, chicken salads, pasta salads, potato salads, high-protein meals, and homemade salad dressings for everyday cooking. Whether you\'re looking for a quick lunch, a healthy side dish, or a new salad to try, you\'ll find plenty of recipes to explore.', DSR_TEXT ) );
$about_btn_text = get_theme_mod( 'dsr_about_btn_text', esc_html__( 'ABOUT DAILY SALAD RECIPES', DSR_TEXT ) );
$about_btn_url  = get_theme_mod( 'dsr_about_btn_url', home_url( '/about/' ) );
?>

<section class="dsr-about-strip" aria-label="<?php esc_attr_e( 'About section', DSR_TEXT ); ?>">
	<div class="container">
		<div class="about-strip-grid">

			<!-- Image -->
			<div class="about-strip__image-wrap">
				<?php if ( $about_image_id ) : ?>
					<?php echo wp_get_attachment_image( absint( $about_image_id ), 'dsr-feature', false, array( 'alt' => esc_attr( $about_heading ), 'loading' => 'lazy' ) ); ?>
				<?php else : ?>
					<img src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80" alt="<?php echo esc_attr( $about_heading ); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-lg);" />
				<?php endif; ?>
			</div>

			<!-- Content -->
			<div class="about-strip__content">

				<span class="section-eyebrow" data-customizer="dsr_about_eyebrow"><?php echo esc_html( $about_eyebrow ); ?></span>

				<h2 class="about-strip__heading" data-customizer="dsr_about_heading">
					<?php echo esc_html( $about_heading ); ?>
				</h2>

				<p class="about-strip__text" data-customizer="dsr_about_text">
					<?php echo esc_html( $about_text ); ?>
				</p>

				<!-- Highlights -->
				<div class="about-strip__highlights">
					<div class="about-highlight">
						<div class="about-highlight__num">200+</div>
						<div class="about-highlight__label"><?php esc_html_e( 'Salad Recipes', DSR_TEXT ); ?></div>
					</div>
					<div class="about-highlight">
						<div class="about-highlight__num">100%</div>
						<div class="about-highlight__label"><?php esc_html_e( 'Fresh Ideas', DSR_TEXT ); ?></div>
					</div>
				</div>

				<?php if ( $about_btn_text && $about_btn_url ) : ?>
					<a href="<?php echo esc_url( $about_btn_url ); ?>" class="btn btn--primary" data-customizer="dsr_about_btn_text">
						<?php echo esc_html( $about_btn_text ); ?>
					</a>
				<?php endif; ?>

			</div>

		</div>
	</div>
</section>

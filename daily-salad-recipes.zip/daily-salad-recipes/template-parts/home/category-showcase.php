<?php
/**
 * Daily Salad Recipes — Category Showcase Section
 *
 * Used to showcase recipes from specific top categories on the homepage.
 * Accepts $args['showcase_num'] (1 or 2).
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$num = isset( $args['showcase_num'] ) ? absint( $args['showcase_num'] ) : 1;

$enabled = get_theme_mod( "dsr_showcase_enable_{$num}", true );
if ( ! $enabled ) {
	return;
}

$default_eyebrows  = array(
	1 => esc_html__( 'FRESH & NOURISHING', DSR_TEXT ),
	2 => esc_html__( 'FILLING & FLAVORFUL', DSR_TEXT ),
);
$default_titles    = array(
	1 => esc_html__( 'Healthy Salad Recipes', DSR_TEXT ),
	2 => esc_html__( 'Easy Chicken Salad Recipes', DSR_TEXT ),
);
$default_subtitles = array(
	1 => esc_html__( 'Fresh and satisfying salads for everyday meals.', DSR_TEXT ),
	2 => esc_html__( 'Flavorful chicken salads for quick and satisfying meals.', DSR_TEXT ),
);
$default_btn_texts = array(
	1 => esc_html__( 'EXPLORE HEALTHY SALADS', DSR_TEXT ),
	2 => esc_html__( 'EXPLORE CHICKEN SALADS', DSR_TEXT ),
);

$cat_id         = get_theme_mod( "dsr_showcase_cat_{$num}", 0 );
$custom_eyebrow  = get_theme_mod( "dsr_showcase_eyebrow_{$num}", $default_eyebrows[ $num ] ?? $default_eyebrows[1] );
$custom_title    = get_theme_mod( "dsr_showcase_title_{$num}", $default_titles[ $num ] ?? $default_titles[1] );
$custom_sub      = get_theme_mod( "dsr_showcase_subtitle_{$num}", $default_subtitles[ $num ] ?? $default_subtitles[1] );
$btn_text        = get_theme_mod( "dsr_showcase_btn_text_{$num}", $default_btn_texts[ $num ] ?? $default_btn_texts[1] );
$custom_btn_url  = get_theme_mod( "dsr_showcase_btn_url_{$num}", '' );

$query_args = array(
	'post_type'           => array( 'post', 'recipe' ),
	'posts_per_page'      => 4,
	'orderby'             => 'date',
	'order'               => 'DESC',
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
);

if ( ! empty( $custom_btn_url ) ) {
	$section_url = $custom_btn_url;
} elseif ( $cat_id > 0 ) {
	$query_args['cat'] = absint( $cat_id );
	$cat_obj           = get_category( $cat_id );
	$section_url       = $cat_obj ? get_category_link( $cat_obj ) : home_url( '/recipes/' );
} else {
	$section_url = home_url( '/recipes/' );
}

$showcase_query = new WP_Query( $query_args );

if ( ! $showcase_query->have_posts() ) {
	wp_reset_postdata();
	return;
}
?>

<section class="dsr-category-showcase dsr-category-showcase--<?php echo esc_attr( $num ); ?>" aria-label="<?php echo esc_attr( $custom_title ); ?>">
	<div class="container">

		<div class="section-header section-header--left">
			<div>
				<span class="section-eyebrow" data-customizer="dsr_showcase_eyebrow_<?php echo esc_attr( $num ); ?>"><?php echo esc_html( $custom_eyebrow ); ?></span>
				<h2 class="section-title" data-customizer="dsr_showcase_title_<?php echo esc_attr( $num ); ?>"><?php echo esc_html( $custom_title ); ?></h2>
				<p class="section-subtitle" data-customizer="dsr_showcase_subtitle_<?php echo esc_attr( $num ); ?>"><?php echo esc_html( $custom_sub ); ?></p>
			</div>
			<a href="<?php echo esc_url( $section_url ); ?>" class="section-link" data-customizer="dsr_showcase_btn_text_<?php echo esc_attr( $num ); ?>">
				<?php echo esc_html( $btn_text ); ?>
			</a>
		</div>

		<div class="recipe-grid recipe-grid--4">
			<?php
			while ( $showcase_query->have_posts() ) :
				$showcase_query->the_post();
				get_template_part( 'template-parts/content/content', 'recipe' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>

	</div>
</section>

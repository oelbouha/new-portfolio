<?php
/**
 * Daily Salad Recipes — Featured Categories
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cat_eyebrow  = get_theme_mod( 'dsr_cat_eyebrow', esc_html__( 'EXPLORE', DSR_TEXT ) );
$cat_heading  = get_theme_mod( 'dsr_cat_heading', esc_html__( 'Browse Salad Recipes by Category', DSR_TEXT ) );
$cat_subtitle = get_theme_mod( 'dsr_cat_subtitle', esc_html__( 'Find the right salad for any meal, from fresh vegetables and green salads to hearty chicken, potato, and healthy salad recipes.', DSR_TEXT ) );

$cat_mode = get_theme_mod( 'dsr_cat_mode', 'auto' );

// Exclude list (IDs, names, or slugs)
$exclude_setting = get_theme_mod( 'dsr_cat_exclude_list', '' );
$exclude_terms   = array_filter( array_map( 'trim', explode( ',', $exclude_setting ) ) );

$fallback_images = array(
	'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=400&q=80',
	'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=400&q=80',
	'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80',
	'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?auto=format&fit=crop&w=400&q=80',
	'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=400&q=80',
	'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=400&q=80',
);

$cards_to_render = array();

// Fetch all database categories
$db_categories = get_categories(
	array(
		'orderby'    => 'count',
		'order'      => 'DESC',
		'exclude'    => array( get_option( 'default_category' ) ),
		'hide_empty' => false,
	)
);

// Exclude helper function
$is_cat_excluded = function( $cat_obj ) use ( $exclude_terms ) {
	if ( ! $cat_obj || is_wp_error( $cat_obj ) ) {
		return true;
	}
	if ( empty( $exclude_terms ) ) {
		return false;
	}
	foreach ( $exclude_terms as $term ) {
		if ( is_numeric( $term ) && absint( $term ) === $cat_obj->term_id ) {
			return true;
		}
		if ( strtolower( $term ) === strtolower( $cat_obj->slug ) || strtolower( $term ) === strtolower( $cat_obj->name ) ) {
			return true;
		}
	}
	return false;
};

if ( 'auto' === $cat_mode ) {
	if ( ! empty( $db_categories ) && ! is_wp_error( $db_categories ) ) {
		$idx = 1;
		foreach ( $db_categories as $cat ) {
			if ( $is_cat_excluded( $cat ) ) {
				continue;
			}
			$custom_img = get_theme_mod( "dsr_cat_image_{$idx}", 0 );
			$term_img   = get_term_meta( $cat->term_id, 'thumbnail_id', true );
			$img_id     = ! empty( $custom_img ) ? $custom_img : ( ! empty( $term_img ) ? $term_img : 0 );

			$cards_to_render[] = array(
				'name'      => $cat->name,
				'count_txt' => sprintf( _n( '%d Recipe', '%d Recipes', $cat->count, DSR_TEXT ), $cat->count ),
				'url'       => get_category_link( $cat->term_id ),
				'img_id'    => $img_id,
				'fallback'  => $fallback_images[ ( $idx - 1 ) % count( $fallback_images ) ],
			);
			$idx++;
		}
	}
} else {
	// Custom or Manual Mode: Loop through items 1..8 with enable checkboxes and category pickers
	for ( $i = 1; $i <= 8; $i++ ) {
		$enabled = get_theme_mod( "dsr_cat_enable_{$i}", true );
		if ( ! $enabled ) {
			continue; // User unchecked / removed this item!
		}

		$cat_id      = absint( get_theme_mod( "dsr_cat_select_{$i}", 0 ) );
		$custom_name = get_theme_mod( "dsr_cat_name_{$i}", '' );
		$custom_cnt  = get_theme_mod( "dsr_cat_count_{$i}", '' );
		$custom_url  = get_theme_mod( "dsr_cat_url_{$i}", '' );
		$custom_img  = get_theme_mod( "dsr_cat_image_{$i}", 0 );

		if ( $cat_id > 0 ) {
			$cat_obj = get_category( $cat_id );
			if ( $cat_obj && ! is_wp_error( $cat_obj ) && ! $is_cat_excluded( $cat_obj ) ) {
				$term_img   = get_term_meta( $cat_obj->term_id, 'thumbnail_id', true );
				$img_id     = ! empty( $custom_img ) ? $custom_img : ( ! empty( $term_img ) ? $term_img : 0 );
				$cards_to_render[] = array(
					'name'      => ! empty( $custom_name ) ? $custom_name : $cat_obj->name,
					'count_txt' => ! empty( $custom_cnt ) ? $custom_cnt : sprintf( _n( '%d Recipe', '%d Recipes', $cat_obj->count, DSR_TEXT ), $cat_obj->count ),
					'url'       => ! empty( $custom_url ) ? $custom_url : get_category_link( $cat_obj->term_id ),
					'img_id'    => $img_id,
					'fallback'  => $fallback_images[ ( $i - 1 ) % count( $fallback_images ) ],
				);
			}
		} elseif ( ! empty( $db_categories[ $i - 1 ] ) ) {
			$cat_obj = $db_categories[ $i - 1 ];
			if ( ! $is_cat_excluded( $cat_obj ) ) {
				$term_img   = get_term_meta( $cat_obj->term_id, 'thumbnail_id', true );
				$img_id     = ! empty( $custom_img ) ? $custom_img : ( ! empty( $term_img ) ? $term_img : 0 );
				$cards_to_render[] = array(
					'name'      => ! empty( $custom_name ) ? $custom_name : $cat_obj->name,
					'count_txt' => ! empty( $custom_cnt ) ? $custom_cnt : sprintf( _n( '%d Recipe', '%d Recipes', $cat_obj->count, DSR_TEXT ), $cat_obj->count ),
					'url'       => ! empty( $custom_url ) ? $custom_url : get_category_link( $cat_obj->term_id ),
					'img_id'    => $img_id,
					'fallback'  => $fallback_images[ ( $i - 1 ) % count( $fallback_images ) ],
				);
			}
		} elseif ( ! empty( $custom_name ) || $i <= 3 ) {
			$default_names = array(
				1 => esc_html__( 'Chicken Salad Recipes', DSR_TEXT ),
				2 => esc_html__( 'Potato Salad Recipes', DSR_TEXT ),
				3 => esc_html__( 'International Salad Recipes', DSR_TEXT ),
			);
			$name = ! empty( $custom_name ) ? $custom_name : ( $default_names[ $i ] ?? '' );
			if ( ! empty( $name ) ) {
				$cards_to_render[] = array(
					'name'      => $name,
					'count_txt' => ! empty( $custom_cnt ) ? $custom_cnt : esc_html__( '1 Recipe', DSR_TEXT ),
					'url'       => ! empty( $custom_url ) ? $custom_url : home_url( '/recipes/' ),
					'img_id'    => $custom_img,
					'fallback'  => $fallback_images[ ( $i - 1 ) % count( $fallback_images ) ],
				);
			}
		}
	}
}
?>

<section class="dsr-categories" aria-label="<?php esc_attr_e( 'Recipe Categories', DSR_TEXT ); ?>">
	<div class="container">

		<div class="section-header">
			<?php if ( $cat_eyebrow ) : ?>
				<span class="section-eyebrow" data-customizer="dsr_cat_eyebrow"><?php echo esc_html( $cat_eyebrow ); ?></span>
			<?php endif; ?>
			<?php if ( $cat_heading ) : ?>
				<h2 class="section-title" data-customizer="dsr_cat_heading"><?php echo esc_html( $cat_heading ); ?></h2>
			<?php endif; ?>
			<?php if ( $cat_subtitle ) : ?>
				<p class="section-subtitle" data-customizer="dsr_cat_subtitle"><?php echo esc_html( $cat_subtitle ); ?></p>
			<?php endif; ?>
		</div>

		<div class="categories-grid">
			<?php foreach ( $cards_to_render as $card ) : ?>
				<a
					href="<?php echo esc_url( $card['url'] ); ?>"
					class="category-card"
					aria-label="<?php echo esc_attr( sprintf( __( 'Browse %s', DSR_TEXT ), $card['name'] ) ); ?>"
				>
					<div class="category-card__image-wrap">
						<?php if ( ! empty( $card['img_id'] ) ) : ?>
							<?php echo wp_get_attachment_image( absint( $card['img_id'] ), 'dsr-category', false, array( 'alt' => esc_attr( $card['name'] ), 'loading' => 'lazy' ) ); ?>
						<?php else : ?>
							<img src="<?php echo esc_url( $card['fallback'] ); ?>" alt="<?php echo esc_attr( $card['name'] ); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;" />
						<?php endif; ?>
					</div>
					<span class="category-card__name"><?php echo esc_html( $card['name'] ); ?></span>
					<span class="category-card__count"><?php echo esc_html( $card['count_txt'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>

	</div>
</section>


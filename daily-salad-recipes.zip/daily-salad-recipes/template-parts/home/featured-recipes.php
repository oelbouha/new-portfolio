<?php
/**
 * Daily Salad Recipes — Featured Recipes Grid
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Query sticky posts first, then recent popular posts.
$featured_query = new WP_Query(
	array(
		'post_type'           => array( 'post', 'recipe' ),
		'posts_per_page'      => 8,
		'post__in'            => get_option( 'sticky_posts' ),
		'orderby'             => 'date',
		'order'               => 'DESC',
		'ignore_sticky_posts' => false,
		'no_found_rows'       => true,
	)
);

// If no sticky posts, get recent posts.
if ( ! $featured_query->have_posts() ) {
	$featured_query = new WP_Query(
		array(
			'post_type'           => array( 'post', 'recipe' ),
			'posts_per_page'      => 8,
			'orderby'             => 'comment_count',
			'order'               => 'DESC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
}

if ( ! $featured_query->have_posts() ) {
	wp_reset_postdata();
	return;
}
?>

<section class="dsr-recipe-section" aria-label="<?php esc_attr_e( 'Popular Recipes', DSR_TEXT ); ?>">
	<div class="container">

		<?php
		$feat_eyebrow   = get_theme_mod( 'dsr_featured_eyebrow', esc_html__( 'TRY THESE', DSR_TEXT ) );
		$feat_heading   = get_theme_mod( 'dsr_featured_heading', esc_html__( 'Popular Salad Recipes', DSR_TEXT ) );
		$feat_subtitle  = get_theme_mod( 'dsr_featured_subtitle', esc_html__( 'Simple and delicious salad recipes worth trying.', DSR_TEXT ) );
		$feat_link_text = get_theme_mod( 'dsr_featured_link_text', esc_html__( 'All Recipes', DSR_TEXT ) );
		$feat_link_url  = get_theme_mod( 'dsr_featured_link_url', '' );
		$feat_url       = ! empty( $feat_link_url ) ? $feat_link_url : home_url( '/recipes/' );
		?>
		<div class="section-header section-header--left">
			<div>
				<?php if ( $feat_eyebrow ) : ?>
					<span class="section-eyebrow" data-customizer="dsr_featured_eyebrow"><?php echo esc_html( $feat_eyebrow ); ?></span>
				<?php endif; ?>
				<?php if ( $feat_heading ) : ?>
					<h2 class="section-title" data-customizer="dsr_featured_heading"><?php echo esc_html( $feat_heading ); ?></h2>
				<?php endif; ?>
				<?php if ( $feat_subtitle ) : ?>
					<p class="section-subtitle" data-customizer="dsr_featured_subtitle"><?php echo esc_html( $feat_subtitle ); ?></p>
				<?php endif; ?>
			</div>
			<a href="<?php echo esc_url( $feat_url ); ?>" class="section-link" data-customizer="dsr_featured_link_text">
				<?php echo esc_html( $feat_link_text ); ?>
			</a>
		</div>

		<div class="recipe-grid recipe-grid--4">
			<?php
			while ( $featured_query->have_posts() ) :
				$featured_query->the_post();
				get_template_part( 'template-parts/content/content', 'recipe' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>

	</div>
</section>

<?php
/**
 * Daily Salad Recipes — Homepage Hero
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Customizer values.
$hero_image_id    = get_theme_mod( 'dsr_hero_image', 0 );
$hero_eyebrow     = get_theme_mod( 'dsr_hero_eyebrow', esc_html__( 'FRESH • SIMPLE • EVERYDAY', DSR_TEXT ) );
$hero_heading     = get_theme_mod( 'dsr_hero_heading', esc_html__( 'Daily Salad Recipes for Every Day', DSR_TEXT ) );
$hero_description = get_theme_mod( 'dsr_hero_description', esc_html__( 'Fresh, easy, and delicious salad recipes for everyday meals. Discover simple salads made with fresh ingredients.', DSR_TEXT ) );
$btn_primary_text = get_theme_mod( 'dsr_hero_btn_primary_text', esc_html__( 'EXPLORE SALAD RECIPES', DSR_TEXT ) );
$btn_primary_url  = get_theme_mod( 'dsr_hero_btn_primary_url', home_url( '/recipes/' ) );
$btn_sec_text     = get_theme_mod( 'dsr_hero_btn_secondary_text', esc_html__( 'VIEW LATEST RECIPES', DSR_TEXT ) );
$btn_sec_url      = get_theme_mod( 'dsr_hero_btn_secondary_url', '#latest-recipes' );
?>

<section class="dsr-hero" aria-label="<?php esc_attr_e( 'Homepage hero', DSR_TEXT ); ?>">

	<!-- Background Image -->
	<div class="dsr-hero__bg" aria-hidden="true">
		<?php if ( $hero_image_id ) : ?>
			<?php echo wp_get_attachment_image( absint( $hero_image_id ), 'dsr-hero', false, array( 'alt' => '', 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?>
		<?php else : ?>
			<img src="https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1600&q=80" alt="Fresh Salad Recipes" loading="eager" style="width:100%;height:100%;object-fit:cover;" />
		<?php endif; ?>
	</div>

	<!-- Overlay -->
	<div class="dsr-hero__overlay" aria-hidden="true"></div>

	<!-- Content -->
	<div class="container">
		<div class="dsr-hero__content">

			<?php if ( $hero_eyebrow ) : ?>
				<span class="dsr-hero__eyebrow" data-customizer="dsr_hero_eyebrow">
					<?php echo esc_html( $hero_eyebrow ); ?>
				</span>
			<?php endif; ?>

			<h1 class="dsr-hero__heading" data-customizer="dsr_hero_heading">
				<?php echo esc_html( $hero_heading ); ?>
			</h1>

			<?php if ( $hero_description ) : ?>
				<p class="dsr-hero__description" data-customizer="dsr_hero_description">
					<?php echo esc_html( $hero_description ); ?>
				</p>
			<?php endif; ?>

			<div class="dsr-hero__actions">
				<?php if ( $btn_primary_text && $btn_primary_url ) : ?>
					<a href="<?php echo esc_url( $btn_primary_url ); ?>" class="btn btn--accent btn--lg" data-customizer="dsr_hero_btn_primary_text">
						<?php echo esc_html( $btn_primary_text ); ?>
					</a>
				<?php endif; ?>

				<?php if ( $btn_sec_text && $btn_sec_url ) : ?>
					<a href="<?php echo esc_url( $btn_sec_url ); ?>" class="btn btn--ghost btn--lg" data-customizer="dsr_hero_btn_secondary_text">
						<?php echo esc_html( $btn_sec_text ); ?>
					</a>
				<?php endif; ?>
			</div>

		</div>
	</div>

</section>

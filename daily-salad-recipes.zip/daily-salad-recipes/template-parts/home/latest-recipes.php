<?php
/**
 * Daily Salad Recipes — Latest Recipes Section
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$latest = new WP_Query(
	array(
		'post_type'           => array( 'post', 'recipe' ),
		'posts_per_page'      => 8,
		'orderby'             => 'date',
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

if ( ! $latest->have_posts() ) {
	wp_reset_postdata();
	return;
}
?>

<section class="dsr-latest-recipes" aria-label="<?php esc_attr_e( 'Latest Recipes', DSR_TEXT ); ?>">
	<div class="container">

		<?php
		$latest_eyebrow   = get_theme_mod( 'dsr_latest_eyebrow', esc_html__( 'NEW RECIPES', DSR_TEXT ) );
		$latest_heading   = get_theme_mod( 'dsr_latest_heading', esc_html__( 'Latest Salad Recipes', DSR_TEXT ) );
		$latest_link_text = get_theme_mod( 'dsr_latest_link_text', esc_html__( 'View All', DSR_TEXT ) );
		$latest_link_url  = get_theme_mod( 'dsr_latest_link_url', '' );

		if ( empty( $latest_link_url ) ) {
			$blog_page_id    = get_option( 'page_for_posts' );
			$latest_link_url = $blog_page_id ? get_permalink( $blog_page_id ) : home_url( '/recipes/' );
		}
		?>
		<div class="section-header section-header--left">
			<div>
				<?php if ( $latest_eyebrow ) : ?>
					<span class="section-eyebrow" data-customizer="dsr_latest_eyebrow"><?php echo esc_html( $latest_eyebrow ); ?></span>
				<?php endif; ?>
				<?php if ( $latest_heading ) : ?>
					<h2 class="section-title" data-customizer="dsr_latest_heading"><?php echo esc_html( $latest_heading ); ?></h2>
				<?php endif; ?>
			</div>
			<a href="<?php echo esc_url( $latest_link_url ); ?>" class="section-link" data-customizer="dsr_latest_link_text"><?php echo esc_html( $latest_link_text ); ?></a>
		</div>

		<div class="recipe-grid recipe-grid--4">
			<?php
			while ( $latest->have_posts() ) :
				$latest->the_post();
				get_template_part( 'template-parts/content/content', 'recipe' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>

	</div>
</section>

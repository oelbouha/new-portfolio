<?php
/**
 * Daily Salad Recipes — Newsletter Section
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$newsletter_eyebrow  = get_theme_mod( 'dsr_newsletter_eyebrow', esc_html__( 'Fresh salad newsletter', DSR_TEXT ) );
$newsletter_badge    = get_theme_mod( 'dsr_newsletter_badge', esc_html__( 'Stay inspired', DSR_TEXT ) );
$newsletter_heading  = get_theme_mod( 'dsr_newsletter_heading', esc_html__( 'Fresh Recipes in Your Inbox', DSR_TEXT ) );
$newsletter_text     = get_theme_mod( 'dsr_newsletter_text', esc_html__( 'Get fresh salad recipes, healthy meal ideas, and delicious inspiration delivered straight to your inbox.', DSR_TEXT ) );
$newsletter_image_id = get_theme_mod( 'dsr_newsletter_image', 0 );
?>

<section class="dsr-newsletter" id="newsletter" aria-label="<?php esc_attr_e( 'Newsletter signup', DSR_TEXT ); ?>">
	<div class="container">
		<div class="newsletter-grid">

			<!-- Left: Image -->
			<div class="newsletter__image-wrap">
				<?php if ( $newsletter_image_id ) : ?>
					<?php echo wp_get_attachment_image( absint( $newsletter_image_id ), 'dsr-feature', false, array( 'alt' => esc_attr__( 'Fresh salad recipes', DSR_TEXT ), 'loading' => 'lazy' ) ); ?>
				<?php else : ?>
					<img src="https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80" alt="Fresh salad newsletter" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-lg);" />
				<?php endif; ?>
			</div>

			<!-- Right: Content -->
			<div class="newsletter__content">
				<span class="newsletter__eyebrow"><?php echo esc_html( $newsletter_eyebrow ); ?> • <?php echo esc_html( $newsletter_badge ); ?></span>

				<h2 class="newsletter__heading" data-customizer="dsr_newsletter_heading">
					<?php echo esc_html( $newsletter_heading ); ?>
				</h2>

				<p class="newsletter__text" data-customizer="dsr_newsletter_text">
					<?php echo esc_html( $newsletter_text ); ?>
				</p>

				<!-- Widget area: insert your newsletter plugin here -->
				<?php if ( is_active_sidebar( 'newsletter-form' ) ) : ?>
					<div class="newsletter-widget-area">
						<?php dynamic_sidebar( 'newsletter-form' ); ?>
					</div>
				<?php endif; ?>

				<!-- Fallback form -->
				<div class="newsletter-fallback-form">
					<form action="#" method="post" onsubmit="event.preventDefault(); alert('Thank you for subscribing!');" class="form-row">
						<input
							type="email"
							placeholder="<?php esc_attr_e( 'Your email address...', DSR_TEXT ); ?>"
							aria-label="<?php esc_attr_e( 'Email address', DSR_TEXT ); ?>"
							required
						/>
						<button type="submit" class="btn btn--accent">
							<?php esc_html_e( 'Subscribe Free', DSR_TEXT ); ?>
						</button>
					</form>
					<p class="newsletter-privacy">
						<?php esc_html_e( 'No spam. Unsubscribe anytime.', DSR_TEXT ); ?>
					</p>
				</div>

			</div>
		</div>
	</div>
</section>

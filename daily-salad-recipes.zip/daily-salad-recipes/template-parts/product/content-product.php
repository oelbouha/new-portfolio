<?php
/**
 * Daily Salad Recipes — Product Card (for loops/grids)
 *
 * Rendered on the Products Archive page and product category archives.
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$price        = dsr_get_product_price();
$purchase_url = dsr_get_product_purchase_url();
$short_desc   = dsr_get_product_short_desc();
$badge        = dsr_get_product_badge();
$terms        = get_the_terms( get_the_ID(), 'product_category' );
$cat_name     = ( ! empty( $terms ) && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
?>

<article <?php post_class( 'dsr-product-card' ); ?> id="product-<?php the_ID(); ?>">

	<a href="<?php the_permalink(); ?>" class="dsr-product-card__image-wrap" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
		<?php if ( $badge ) : ?>
			<span class="dsr-product-card__badge"><?php echo esc_html( $badge ); ?></span>
		<?php endif; ?>

		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'dsr-card', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) ); ?>
		<?php else : ?>
			<img src="https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="lazy" />
		<?php endif; ?>
	</a>

	<div class="dsr-product-card__body">
		<?php if ( $cat_name ) : ?>
			<span class="dsr-product-card__category"><?php echo esc_html( $cat_name ); ?></span>
		<?php endif; ?>

		<h3 class="dsr-product-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>

		<div class="dsr-product-card__footer">
			<?php if ( $price ) : ?>
				<div class="dsr-product-card__price"><?php echo esc_html( $price ); ?></div>
			<?php endif; ?>

			<div class="dsr-product-card__actions">
				<a href="<?php echo esc_url( $purchase_url ); ?>" class="btn btn--accent btn--sm" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Buy %s now', DSR_TEXT ), get_the_title() ) ); ?>">
					<?php esc_html_e( 'Buy Now', DSR_TEXT ); ?>
				</a>
				<a href="<?php the_permalink(); ?>" class="btn btn--secondary btn--sm" aria-label="<?php echo esc_attr( sprintf( __( 'View details for %s', DSR_TEXT ), get_the_title() ) ); ?>">
					<?php esc_html_e( 'View', DSR_TEXT ); ?>
				</a>
			</div>
		</div>
	</div>

</article>

<?php
/**
 * Daily Salad Recipes — Recipe Header Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$categories = get_the_category();
?>

<header class="dsr-recipe-header">
	<?php dsr_breadcrumbs(); ?>

	<?php if ( ! empty( $categories ) ) : ?>
		<div class="recipe-meta-cats">
			<?php foreach ( $categories as $cat ) : ?>
				<a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="cat-pill"><?php echo esc_html( $cat->name ); ?></a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<h1 class="recipe-entry-title"><?php the_title(); ?></h1>

	<div class="recipe-meta-row">
		<div class="recipe-author-meta">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 40, '', get_the_author(), array( 'class' => 'author-avatar' ) ); ?>
			<div class="author-info">
				<span class="byline"><?php esc_html_e( 'By', DSR_TEXT ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a></span>
				<time class="published-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</div>
		</div>

		<div class="recipe-quick-info">
			<span class="read-time">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
				<?php echo esc_html( dsr_reading_time() ); ?>
			</span>
		</div>
	</div>
</header>

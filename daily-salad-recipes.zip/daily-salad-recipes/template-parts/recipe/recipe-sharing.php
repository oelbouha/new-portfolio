<?php
/**
 * Daily Salad Recipes — Social Share Buttons Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

dsr_social_share_buttons();

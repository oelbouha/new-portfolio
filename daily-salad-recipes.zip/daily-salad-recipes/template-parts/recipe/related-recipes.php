<?php
/**
 * Daily Salad Recipes — Related Recipes Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$categories = wp_get_post_categories( get_the_ID() );

if ( empty( $categories ) ) {
	return;
}

$related_query = new WP_Query(
	array(
		'category__in'        => $categories,
		'post__not_in'        => array( get_the_ID() ),
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => 1,
	)
);

if ( $related_query->have_posts() ) :
	?>
	<section class="related-recipes-section">
		<h2 class="section-title"><?php esc_html_e( 'You Might Also Like', DSR_TEXT ); ?></h2>
		<div class="recipes-grid recipes-grid-3">
			<?php
			while ( $related_query->have_posts() ) :
				$related_query->the_post();
				get_template_part( 'template-parts/content/content-recipe' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</section>
<?php endif; ?>

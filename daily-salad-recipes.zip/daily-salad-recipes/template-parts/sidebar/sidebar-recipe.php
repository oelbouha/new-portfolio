<?php
/**
 * Daily Salad Recipes — Sidebar Template Part
 *
 * @package DailySaladRecipes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_sidebar();
